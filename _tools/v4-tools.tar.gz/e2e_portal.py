import json,sys
from playwright.sync_api import sync_playwright
S='/tmp/claude-0/-home-claude/0118b113-26d6-5c1b-9f2e-012384449abe/scratchpad/'
B='http://localhost:8765/'
errs=[]
def log(*a): print(*a,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':1280,'height':900}); pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
    pg.on('console',lambda m: errs.append('CONSOLE '+m.text) if m.type=='error' and 'tile' not in m.text.lower() and 'ERR_' not in m.text and 'Failed to load resource' not in m.text else None)
    # block external fonts/tiles fast
    ctx.route('**/*',lambda r: r.abort() if ('googleapis' in r.request.url or 'gstatic' in r.request.url or 'openstreetmap' in r.request.url or 'googleusercontent' in r.request.url) else r.continue_())
    pg.goto(B+'portal.html'); pg.wait_for_timeout(600)
    assert pg.locator('.login').is_visible(); log('login visible; demo bar:',pg.locator('#demoBar').is_visible())
    pg.screenshot(path=S+'shots/p-login.png')
    # agent flow
    pg.click('text=Try as Agent'); pg.wait_for_selector('.demo-code b'); code=pg.inner_text('.demo-code b'); log('demo code',code)
    pg.click('text=Fill it in'); pg.wait_for_selector('.p-tabs'); log('signed in as',pg.inner_text('#who')[:40].replace('\n',' '))
    pg.wait_for_selector('.empty-state'); assert 'No listings yet' in pg.inner_text('#view')
    pg.click('text=+ New listing >> nth=0'); pg.wait_for_selector('#ed')
    pg.fill('#f_title','Quiet two-bedroom beside the BTS'); pg.fill('#f_project','Test Residence'); pg.select_option('#f_area','sukhumvit'); pg.select_option('#f_type','Condo')
    pg.fill('#f_price_rent','45,000'); pg.fill('#f_beds','2'); pg.fill('#f_baths','2'); pg.fill('#f_size','62'); pg.fill('#f_floor','12')
    pg.check('input[name=pets]'); pg.check('input[name=tag][value=bts]')
    pg.fill('#f_story','A calm corner unit.\n\nSecond paragraph <b>not bold</b>.'); pg.fill('#f_address_private','Unit 12/34')
    pg.screenshot(path=S+'shots/p-editor-top.png',full_page=False)
    # try submit early: should be not ready
    pg.click('button[data-act=submit]'); pg.wait_for_timeout(500)
    log('toast after early submit:',pg.inner_text('#toast')); assert pg.locator('.fld.err').count()>0
    # upload photos
    pg.set_input_files('#fileIn',[S+'testph0.jpg',S+'testph1.jpg',S+'testph2.jpg']); pg.wait_for_function("document.querySelectorAll('#photos .ph').length===3",timeout=20000)
    log('photos',pg.locator('#photos .ph').count(),'hash',pg.evaluate('location.hash'))
    # reorder: move 2nd earlier
    pg.locator('#photos .ph').nth(1).locator('button[data-act=mv][data-d="-1"]').click(); pg.wait_for_timeout(400)
    # pin via lat/lng
    pg.fill('#f_lat','13.7367'); pg.fill('#f_lng','100.5601'); pg.dispatch_event('#f_lng','change'); pg.wait_for_timeout(300)
    log('checklist:',pg.inner_text('#barT'))
    pg.screenshot(path=S+'shots/p-editor-full.png',full_page=True)
    pg.click('button[data-act=submit]'); pg.wait_for_selector('.lrow',timeout=8000)
    log('after submit:',pg.inner_text('#toast')); assert 'In review' in pg.inner_text('.lrow') or 'in review' in pg.inner_text('.lrow').lower()
    pg.screenshot(path=S+'shots/p-mine.png')
    # public should not show it
    pg.goto(B+'marketplace.html'); pg.wait_for_timeout(700); assert pg.locator('.hcard[data-id^="l2"]').count()==0
    # admin approves
    pg.goto(B+'portal.html'); pg.wait_for_timeout(500); pg.click('text=Sign out'); pg.click('text=Try as Admin'); pg.wait_for_selector('.demo-code b'); pg.click('text=Fill it in'); pg.wait_for_selector('.p-tabs')
    pg.click('.p-tabs a[href="#queue"]'); pg.wait_for_selector('.rv'); log('queue count',pg.locator('.rv').count()); pg.screenshot(path=S+'shots/p-queue.png',full_page=True)
    pg.click('button[data-act=approve]'); pg.wait_for_selector('.empty-state'); log('approved ->',pg.inner_text('#toast'))
    pg.click('.p-tabs a[href="#team"]'); pg.wait_for_selector('.tbl'); pg.screenshot(path=S+'shots/p-team.png')
    pg.click('.p-tabs a[href="#all"]'); pg.wait_for_selector('.lrow'); pg.screenshot(path=S+'shots/p-all.png')
    # public side
    pg.goto(B+'marketplace.html'); pg.wait_for_timeout(900)
    cards=pg.locator('.hcard[data-id^="l2"]'); log('marketplace live cards',cards.count()); assert cards.count()==1
    log('card text:',cards.first.inner_text().replace('\n',' | ')[:160])
    pg.screenshot(path=S+'shots/p-market.png')
    pg.goto(B+'index.html'); pg.wait_for_timeout(700); log('home new cards ids',pg.eval_on_selector_all('[data-new] .hcard','e=>e.map(x=>x.dataset.id)'))
    pg.goto(B+'map.html'); pg.wait_for_timeout(1200); log('pins',pg.locator('.pin').count(),'list items',pg.locator('.mitem').count()); pg.screenshot(path=S+'shots/p-map.png')
    pg.click('#segIntent button[data-v=buy]'); pg.wait_for_timeout(300); log('buy-only pins',pg.locator('.pin').count())
    pg.click('#segIntent button[data-v=rent]'); pg.wait_for_timeout(300); log('rent-only pins',pg.locator('.pin').count())
    lid=pg.evaluate("JSON.parse(localStorage.getItem('hb-demo-pub'))[0].id"); pub=pg.evaluate("localStorage.getItem('hb-demo-pub')")
    assert 'Unit 12/34' not in pub and '13.7367' not in pub and 'agent@demo' not in pub, 'private data leaked into public cache'
    pg.goto(B+'listing.html?id='+lid); pg.wait_for_timeout(1000); log('listing h1:',pg.inner_text('h1')); pg.screenshot(path=S+'shots/p-listing.png',full_page=True)
    assert '<b>not bold</b>' in pg.inner_text('.story'), 'story shown as plain text'; assert pg.locator('.story b').count()==0
    pg.click('.gal button >> nth=0'); assert pg.locator('#lb.open').count()==1; pg.keyboard.press('Escape')
    pg.goto(B+'book-viewing.html?home='+lid); pg.wait_for_timeout(700); log('booking title:',pg.inner_text('#bvTitle'))
    pg.goto(B+'listing.html?id=nope'); pg.wait_for_timeout(600); log('missing:',pg.inner_text('h1'))
    # Thai
    pg.goto(B+'map.html?lang=th'); pg.wait_for_timeout(1000); pg.screenshot(path=S+'shots/p-map-th.png')
    pg.goto(B+'portal.html?lang=th'); pg.wait_for_timeout(500); pg.screenshot(path=S+'shots/p-portal-th.png')
    pg.goto(B+'listing.html?lang=th&id='+lid); pg.wait_for_timeout(900); pg.screenshot(path=S+'shots/p-listing-th.png',full_page=True)
    # mobile
    m=b.new_context(viewport={'width':390,'height':844}); mp=m.new_page(); mp.route('**/*',lambda r: r.abort() if ('googleapis' in r.request.url or 'gstatic' in r.request.url or 'openstreetmap' in r.request.url) else r.continue_())
    mp.goto(B+'map.html'); mp.wait_for_timeout(1000); mp.screenshot(path=S+'shots/p-map-m.png')
    mp.goto(B+'portal.html'); mp.wait_for_timeout(500); mp.screenshot(path=S+'shots/p-login-m.png')
    log('ERRORS:',errs if errs else 'none')
    b.close()
