from playwright.sync_api import sync_playwright
import json,re,sys
js="""()=>{const out=[];const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode:n=>{const p=n.parentElement;if(!p||['SCRIPT','STYLE','NOSCRIPT'].includes(p.tagName))return NodeFilter.FILTER_REJECT;return n.nodeValue.trim()?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT}});let n;while(n=w.nextNode()){out.push(n.nodeValue.replace(/\\s+/g,' ').trim())}return out}"""
pages=sys.argv[1:]
seen={}
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':900})
    for f in pages:
        pg.goto('http://localhost:8765/'+f); pg.wait_for_timeout(700)
        # open menu/finder to reveal dynamic strings
        for sel in ['.finder-trigger']:
            for i in range(pg.locator(sel).count()):
                try: pg.locator(sel).nth(i).click(timeout=500); pg.wait_for_timeout(100)
                except Exception: pass
        try: pg.locator('.menu').first.click(timeout=500, force=True)
        except Exception: pass
        pg.wait_for_timeout(200)
        for t in pg.evaluate(js):
            seen.setdefault(t,[]).append(f)
    b.close()
json.dump(seen,open('i18n_strings.json','w'),ensure_ascii=False,indent=0)
print(len(seen))
