from playwright.sync_api import sync_playwright
import glob,os,re,sys,json
js=open('extract.py').read().split('js="""')[1].split('"""')[0]
pages=sorted(os.path.basename(f) for f in glob.glob('w4/*.html') if os.path.basename(f) not in ('partner-demo.html','agent-workspace.html','property-sukhumvit.html'))
if len(sys.argv)>1: pages=sys.argv[1:]
res={}
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':900})
    pg.on('pageerror',lambda e:errs.append(str(e)))
    for f in pages:
        pg.goto('http://localhost:8765/'+f+'?lang=th'); pg.wait_for_timeout(1200)
        for t in pg.evaluate(js):
            if re.search('[A-Za-z]{3,}',t) and not re.search('[฀-๿]',t): res.setdefault(t,[]).append(f)
        # attrs
        for a in pg.evaluate("()=>[...document.querySelectorAll('[placeholder],[aria-label],[title],[alt]')].map(e=>[e.getAttribute('placeholder'),e.getAttribute('aria-label'),e.getAttribute('title')]).flat().filter(Boolean)"):
            if re.search('[A-Za-z]{3,}',a) and not re.search('[฀-๿]',a): res.setdefault('ATTR:'+a,[]).append(f)
    b.close()
print('errors',errs)
for s,p in sorted(res.items(),key=lambda x:x[1][0]): print(p[0][:22].ljust(22),repr(s)[:110])
print(len(res))
