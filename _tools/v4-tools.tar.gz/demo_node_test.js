const vm=require('vm'),fs=require('fs'),crypto=require('crypto');
const W='/tmp/claude-0/-home-claude/0118b113-26d6-5c1b-9f2e-012384449abe/scratchpad/w4/';
const store={};const win={localStorage:{getItem:k=>k in store?store[k]:null,setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>{delete store[k]}},crypto:{randomUUID:()=>crypto.randomUUID()}};
win.window=win;const ctx=vm.createContext({...win,TextEncoder,btoa,atob,Intl,Math,JSON,console,Date,Uint8Array,Array,String,Object,Number,RegExp,Error,parseInt,isFinite});
ctx.window=ctx;
vm.runInContext(fs.readFileSync(W+'demo-backend.js','utf8'),ctx);vm.runInContext(fs.readFileSync(W+'demo-env.js','utf8'),ctx);
const d=ctx.HB_DEMO.create();
for(const s of ['','abc','x'.repeat(55),'x'.repeat(56),'x'.repeat(64),'x'.repeat(200),'สวัสดี']){
 if(d._sha256(s)!==crypto.createHash('sha256').update(s).digest('hex'))throw new Error('sha mismatch '+s.length);
 if(d._hmac('key'+s,'msg'+s)!==crypto.createHmac('sha256','key'+s).update('msg'+s).digest('hex'))throw new Error('hmac mismatch '+s.length);
}
console.log('sha/hmac match node');
d.post({action:'login_request',email:'admin@demo.homes.bkk'});
const code=/(\d{6})/.exec(d.mails()[0].subject)[1];
const v=d.post({action:'login_verify',email:'admin@demo.homes.bkk',code});
console.log('login',v.ok,v.user&&v.user.role);
const s=d.post({action:'save_listing',who:v.user.email,token:v.token,listing:{title:'T',project:'P'}});console.log('save',s.ok,s.listing.id);
console.log('users',d.post({action:'users',who:v.user.email,token:v.token}).users.map(u=>u.email));
