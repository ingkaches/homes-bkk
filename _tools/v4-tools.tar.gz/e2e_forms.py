import json,subprocess,threading,http.server,sys
from playwright.sync_api import sync_playwright
# real backend logic (Code.gs) behind a local mock, reached through Playwright's route for the exec URL
EXEC='https://script.google.com/macros/s/TEST/exec'
node=subprocess.Popen(['node','-e','''
const {createEnv}=require("./w4/backend/mocks");const e=createEnv();e.setup();
require("http").createServer((q,s)=>{let b="";q.on("data",d=>b+=d);q.on("end",()=>{
 if(q.url==="/dump"){s.end(JSON.stringify({sheets:e.sheets,mails:e.mails}));return}
 if(q.url==="/fail"){s.statusCode=500;s.end("boom");return}
 s.setHeader("content-type","application/json");s.end(JSON.stringify(q.method==="POST"?e.post(b):e.get()))})}).listen(8771);
'''],cwd='.')
import time,urllib.request; time.sleep(1)
def backend(body): 
    r=urllib.request.Request('http://localhost:8771/',data=body.encode(),method='POST'); return urllib.request.urlopen(r).read().decode()
mode={'fail':False}
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(); 
    for lang in ('en','th'):
        ctx=b.new_context(viewport={'width':1280,'height':900}); pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/config.js',lambda r:r.fulfill(content_type='application/javascript',body="window.HB_CONFIG={endpoint:'%s'};document.documentElement.classList.add('hb-live');"%EXEC))
        def ex(route):
            if mode['fail']: route.abort(); return
            route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=backend(route.request.post_data))
        pg.route(EXEC,ex)
        # ---- submit form
        pg.goto(f'http://localhost:8765/the-home-edit.html?lang={lang}'); pg.wait_for_timeout(700)
        vis=lambda sel: pg.locator(sel).first.is_visible()
        assert not vis('.proto[data-proto]'), 'proto note should be hidden in live mode'
        assert vis('.proto[data-live]'), 'live note visible'
        pg.fill('#name','Somchai'); pg.fill('#contact','+66 81 234 5678'); pg.fill('#where','Nye by Sansiri'); pg.fill('#story','Lovely view')
        # invalid first (auth unticked)
        pg.click('#submitBtn'); pg.wait_for_timeout(200); assert vis('#sf'), 'form stays when auth missing'
        pg.check('#auth')
        mode['fail']=True; pg.click('#submitBtn'); pg.wait_for_timeout(800)
        msg=pg.inner_text('#formErr'); print(lang,'network error msg:',msg[:60]); assert msg and vis('#sf')
        assert pg.input_value('#name')=='Somchai','details kept after failure'
        mode['fail']=False; pg.click('#submitBtn'); pg.wait_for_timeout(1000)
        assert vis('#thanks'),'thanks shown'; ref=pg.inner_text('#refCode'); print(lang,'ref',ref); assert ref.startswith('HB-S-')
        print(lang,'thanks h2:',pg.inner_text('#thanks h2'))
        pg.screenshot(path=f'shots/e2e-submit-{lang}.png')
        # ---- viewing
        pg.goto(f'http://localhost:8765/book-viewing.html?home=tristan&lang={lang}'); pg.wait_for_timeout(700)
        pg.click('[data-next]'); pg.fill('#name','Anna'); pg.fill('#phone','+44 7700 900123')
        pg.click('#detailsForm button[type=submit]'); pg.wait_for_timeout(200)
        assert vis('[data-book-step="2"]'),'needs consent first'; print(lang,'consent msg:',pg.inner_text('#bvErr'))
        pg.check('#consentLive'); pg.click('#detailsForm button[type=submit]'); pg.wait_for_timeout(300)
        assert vis('[data-book-step="3"]')
        mode['fail']=True; pg.click('#confirm'); pg.wait_for_timeout(800); assert vis('[data-book-step="3"]'); print(lang,'step err:',pg.inner_text('.bv-step-err')[:60])
        mode['fail']=False; pg.click('#confirm'); pg.wait_for_timeout(900)
        assert vis('[data-book-step="4"]'); print(lang,'bv ref',pg.inner_text('#bvRef'),'|',pg.inner_text('[data-book-step="4"] h2').replace('\n',' '))
        pg.screenshot(path=f'shots/e2e-book-{lang}.png'); ctx.close()
    # prototype mode untouched (no config override)
    pg=b.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8765/the-home-edit.html'); pg.wait_for_timeout(600)
    assert pg.locator('.proto[data-proto]').first.is_visible() and not pg.locator('.proto[data-live]').first.is_visible()
    pg.fill('#name','T'); pg.fill('#contact','1'); pg.fill('#where','x'); pg.check('#auth'); pg.click('#submitBtn'); pg.wait_for_timeout(400)
    assert pg.locator('#thanks').is_visible() and 'Nothing has been sent' in pg.inner_text('#thanks'); print('prototype mode OK')
    pg.goto('http://localhost:8765/book-viewing.html?home=nye'); pg.click('[data-next]'); pg.fill('#name','T'); pg.fill('#phone','1'); pg.click('#detailsForm button[type=submit]'); pg.click('#confirm'); pg.wait_for_timeout(300)
    assert 'recorded the request in this prototype' in pg.inner_text('[data-book-step="4"]'); print('prototype booking OK')
    b.close()
d=json.loads(urllib.request.urlopen('http://localhost:8771/dump').read())
print('stored submissions',len(d['sheets']['Submissions'])-1,'viewings',len(d['sheets']['Viewing requests'])-1,'mails',len(d['mails']))
print('page errors',errs); node.kill()
