import sys
from playwright.sync_api import sync_playwright
FONTS="""
@font-face{font-family:'Playfair Display';src:url(assets/fonts/_test/playfair-display-latin-500-normal.woff2);font-weight:500;unicode-range:U+0000-00FF,U+2013-2014,U+2018-201D,U+2022,U+2026}
@font-face{font-family:'DM Sans';src:url(assets/fonts/_test/dm-sans-latin-500-normal.woff2);font-weight:400 600;unicode-range:U+0000-00FF,U+2013-2014,U+2018-201D,U+2022,U+2026}
@font-face{font-family:'DM Mono';src:url(assets/fonts/_test/dm-mono-latin-500-normal.woff2);font-weight:400 500;unicode-range:U+0000-00FF,U+2013-2014,U+2018-201D,U+2022,U+2026,U+00B7}
"""
def run(jobs, vp=(1280,900)):
    with sync_playwright() as p:
        b=p.chromium.launch(); pg=b.new_page(viewport={'width':vp[0],'height':vp[1]})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        for url,sel,out in jobs:
            pg.goto('http://localhost:8765/'+url); pg.add_style_tag(content=FONTS); pg.wait_for_timeout(900)
            if sel: 
                pg.locator(sel).first.scroll_into_view_if_needed(); pg.wait_for_timeout(300)
                pg.locator(sel).first.screenshot(path='shots/'+out)
            else: pg.screenshot(path='shots/'+out)
        print('errs',errs); b.close()
if __name__=='__main__':
    run([('property-w8-thonglor-88-88.html','.factcard','px-factcard-w8.png'),('property-tristan-condo.html','.factcard','px-factcard-tristan.png'),('marketplace.html','.hcards','px-cards.png'),('property-the-sukhothai-residences.html','.price-stack','px-suk.png'),('book-viewing.html','.sidebar','px-book.png?') ] if False else [('property-w8-thonglor-88-88.html','.factcard','px-factcard-w8.png'),('property-tristan-condo.html','.factcard','px-factcard-tristan.png'),('marketplace.html','.hcards','px-cards.png'),('property-the-sukhothai-residences.html','.price-stack','px-suk.png'),('book-viewing.html?home=w8-88-88','.sidebar','px-book.png'),('property-w8-thonglor-88-88.html','.units','px-units.png')])
