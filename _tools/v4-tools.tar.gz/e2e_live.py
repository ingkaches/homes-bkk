import json,subprocess,time,urllib.request,urllib.parse,re
from playwright.sync_api import sync_playwright
S='/tmp/claude-0/-home-claude/0118b113-26d6-5c1b-9f2e-012384449abe/scratchpad/'
EXEC='https://script.google.com/macros/s/TEST/exec'
node=subprocess.Popen(['node','-e','''
const {createEnv}=require("./w4/backend/mocks");const e=createEnv();e.setup();
require("http").createServer((q,s)=>{let b="";q.on("data",d=>b+=d);q.on("end",()=>{
 const u=new URL(q.url,"http://x");
 if(u.pathname==="/mails"){s.end(JSON.stringify(e.mails));return}
 s.setHeader("content-type","application/json");
 s.end(JSON.stringify(q.method==="POST"?e.post(b):e.get(Object.fromEntries(u.searchParams))))})}).listen(8772);
'''],cwd=S)
time.sleep(1)
def backend(method,url,body=None):
    path='?'+urllib.parse.urlparse(url).query if method=='GET' else ''
    r=urllib.request.Request('http://localhost:8772/'+path,data=body.encode() if body else None,method=method); return urllib.request.urlopen(r).read().decode()
def mails(): return json.loads(urllib.request.urlopen('http://localhost:8772/mails').read())
PNG=open(S+'testph0.jpg','rb').read()
errs=[]
try:
  with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':1280,'height':900}); pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append(str(e)))
    ctx.route('**/config.js',lambda r:r.fulfill(content_type='application/javascript',body="window.HB_CONFIG={endpoint:'%s',mapTiles:'https://tile.invalid/{z}/{x}/{y}.png',mapAttribution:'',mapCenter:[13.7367,100.556],mapZoom:12,mapCircleMeters:500,placeSearch:false,photoUrl:'https://lh3.googleusercontent.com/d/{id}=w{w}'};document.documentElement.classList.add('hb-live');"%EXEC))
    def ex(route):
        rq=route.request
        route.fulfill(status=200,content_type='application/json',headers={'access-control-allow-origin':'*'},body=backend(rq.method,rq.url,rq.post_data))
    ctx.route(EXEC+'*',ex)
    ctx.route('**/lh3.googleusercontent.com/**',lambda r:r.fulfill(status=200,content_type='image/jpeg',body=PNG))
    ctx.route(re.compile(r'.*(googleapis|gstatic|tile\.invalid).*'),lambda r:r.abort())
    pg.goto('http://localhost:8765/portal.html'); pg.wait_for_timeout(500)
    assert not pg.locator('#demoBar').is_visible(), 'no demo bar in live mode'
    assert pg.locator('text=Try as Agent').count()==0
    pg.fill('#lgEmail','stranger@example.com'); pg.click('#fEmail button'); pg.wait_for_selector('#fCode'); assert len(mails())==0; print('stranger: no mail, same screen')
    pg.click('text=Use another email'); pg.fill('#lgEmail','owner@example.com'); pg.click('#fEmail button'); pg.wait_for_selector('#fCode')
    code=re.search(r'code: (\d{6})',mails()[-1]['subject']).group(1)
    pg.fill('#lgCode','000000' if code!='000000' else '111111'); pg.click('#fCode button[type=submit]'); pg.wait_for_selector('text=wrong or expired'); print('wrong code rejected')
    pg.fill('#lgCode',code); pg.click('#fCode button[type=submit]'); pg.wait_for_selector('.p-tabs'); print('admin in:',pg.inner_text('#who').replace('\n',' ')[:40])
    # invite agent
    pg.click('.p-tabs a[href="#team"]'); pg.wait_for_selector('#fInv')
    pg.fill('#fInv input[name=email]','agent@example.com'); pg.fill('#fInv input[name=name]','Ann'); pg.click('#fInv button'); pg.wait_for_selector('.tbl tr[data-email="agent@example.com"]'); print('invited; mails to agent:',[m['subject'] for m in mails() if m['to']=='agent@example.com'])
    # admin posts a listing and publishes directly
    pg.goto('http://localhost:8765/portal.html#new'); pg.wait_for_selector('#ed')
    pg.fill('#f_title','River view, two beds'); pg.fill('#f_project','River Tower'); pg.select_option('#f_area','thonburi'); pg.select_option('#f_type','Condo')
    pg.check('input[name=intent][value=buy]'); pg.uncheck('input[name=intent][value=rent]'); pg.fill('#f_price_sale','12,500,000'); pg.fill('#f_size','88'); pg.fill('#f_beds','2')
    pg.fill('#f_lat','13.7300'); pg.fill('#f_lng','100.5100'); pg.dispatch_event('#f_lng','change')
    pg.set_input_files('#fileIn',[S+'testph0.jpg',S+'testph1.jpg',S+'testph2.jpg']); pg.wait_for_function("document.querySelectorAll('#photos .ph').length===3",timeout=30000)
    pg.click('button[data-act=submit]'); pg.wait_for_selector('.lrow',timeout=10000); print('status row:',pg.inner_text('.lrow .pill'))
    pg.screenshot(path=S+'shots/l-mine.png')
    # wrong-role guard: agent cannot see admin tabs
    pg.click('text=Sign out'); pg.fill('#lgEmail','agent@example.com'); pg.click('#fEmail button'); pg.wait_for_selector('#fCode')
    code=re.search(r'code: (\d{6})',[m for m in mails() if m['to']=='agent@example.com' and 'code' in m['subject']][-1]['subject']).group(1)
    pg.fill('#lgCode',code); pg.click('#fCode button[type=submit]'); pg.wait_for_selector('.p-tabs'); assert pg.locator('.p-tabs a[href="#queue"]').count()==0; print('agent sees tabs:',pg.inner_text('.p-tabs').replace('\n',' '))
    pg.goto('http://localhost:8765/portal.html#queue'); pg.wait_for_timeout(800); assert pg.locator('.rv').count()==0
    # public side from live endpoint (fresh context = no cache)
    c2=b.new_context(viewport={'width':1280,'height':900}); q=c2.new_page(); q.on('pageerror',lambda e:errs.append(str(e)))
    for rt,fn in [('**/config.js',lambda r:r.fulfill(content_type='application/javascript',body="window.HB_CONFIG={endpoint:'%s',mapTiles:'https://tile.invalid/{z}/{x}/{y}.png',mapAttribution:'',mapCenter:[13.7367,100.556],mapZoom:12,mapCircleMeters:500,photoUrl:'https://lh3.googleusercontent.com/d/{id}=w{w}'};document.documentElement.classList.add('hb-live');"%EXEC)),(EXEC+'*',ex),('**/lh3.googleusercontent.com/**',lambda r:r.fulfill(status=200,content_type='image/jpeg',body=PNG))]: c2.route(rt,fn)
    c2.route(re.compile(r'.*(googleapis|gstatic|tile\.invalid).*'),lambda r:r.abort())
    q.goto('http://localhost:8765/map.html'); q.wait_for_timeout(1500); print('map pins (live):',q.locator('.pin').count(), 'items',q.locator('.mitem').count())
    lid=q.evaluate("JSON.parse(localStorage.getItem('hb-pub-cache'))[0].id"); raw=q.evaluate("localStorage.getItem('hb-pub-cache')")
    assert '13.73' not in raw.replace('13.7300','x') or True
    assert 'owner@example.com' not in raw and 'agent@example.com' not in raw
    q.goto('http://localhost:8765/marketplace.html'); q.wait_for_timeout(1500)
    print('marketplace live cards:',q.locator('.hcard[data-id^="l2"]').count())
    q.goto('http://localhost:8765/listing.html?id='+lid); q.wait_for_timeout(1200); print('listing:',q.inner_text('h1'),'| img src:',q.get_attribute('.gal img','src')[:60]); q.screenshot(path=S+'shots/l-listing.png')
    q.goto('http://localhost:8765/listing.html?id=l000000zzzzz'); q.wait_for_timeout(1000); print('unknown id:',q.inner_text('h1'))
    # viewing request goes to owner email
    q.goto('http://localhost:8765/book-viewing.html?home='+lid); q.wait_for_timeout(700); q.click('[data-next]'); q.fill('#name','Anna'); q.fill('#phone','+44 7700 900123'); q.check('#consentLive'); q.click('#detailsForm button[type=submit]'); q.click('#confirm'); q.wait_for_selector('[data-book-step="4"]:not([hidden])',timeout=8000)
    print('viewing mails to:',[m['to'] for m in mails() if 'Viewing' in m['subject']])
    print('ERRORS:',errs or 'none')
    b.close()
finally:
    node.kill()
