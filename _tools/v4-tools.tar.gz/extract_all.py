from playwright.sync_api import sync_playwright
import json,sys,re,glob,os
js=open('extract.py').read().split('js="""')[1].split('"""')[0]
pages=sorted(os.path.basename(f) for f in glob.glob('w4/*.html'))
seen={}
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':900})
    for f in pages:
        pg.goto('http://localhost:8765/'+f); pg.wait_for_timeout(900)
        for sel in ['.finder-trigger']:
            for i in range(pg.locator(sel).count()):
                try: pg.locator(sel).nth(i).click(timeout=500); pg.wait_for_timeout(80)
                except Exception: pass
        try: pg.locator('.menu').first.click(timeout=500, force=True)
        except Exception: pass
        pg.wait_for_timeout(200)
        for t in pg.evaluate(js): seen.setdefault(t,[]).append(f)
    b.close()
json.dump(seen,open('all_strings.json','w'),ensure_ascii=False,indent=0)
print(len(seen))
