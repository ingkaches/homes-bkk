import html, os, sys
esc = lambda s: html.escape(s, quote=True)
NAVHTML = '<a href="collections.html">Collections</a><a href="marketplace.html">Homes</a><a href="spaces.html">Spaces</a><a href="projects.html">Projects</a><a href="journal.html">Journal</a><a class="button" href="the-home-edit.html">Submit a home</a>'

def fig(base, img, cls):
    n, alt, cap = img
    return f'<figure class="{cls}"><img src="assets/{base}/{n}" alt="{esc(alt)}" loading="lazy"><figcaption>{esc(cap)}</figcaption></figure>'

def build(sp):
    b = sp['dir']
    h = []
    h.append(f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(sp['title'])} — HOMES/BKK</title>
<meta name="description" content="{esc(sp['meta'])}">
<link rel="stylesheet" href="shared.css">
<link rel="stylesheet" href="listing.css">
</head>
<body>
<section class="property-hero" style="--hero:url('assets/{b}/{sp['hero']}');--hero-pos:{sp.get('hero_pos','center')}" data-credit="{esc(sp['credit'])}"><div class="shell"><header class="topbar"><a class="brand" href="index.html">HOMES/<i>BKK</i></a><nav class="nav">{NAVHTML}</nav><button class="menu" data-modal>MENU +</button></header><div class="hero-bottom"><div><div class="eyebrow" style="color:#dce5d9">{esc(sp['kicker'])}</div><h1 class="display">{sp['h1']}</h1></div><p>{esc(sp['dek'])}</p></div></div></section>
<main>''')
    o = sp['opener']
    paras = ''.join(f'<p>{p}</p>' for p in o['paras'])
    facts = ''.join(f'<div{" class=\"wide\"" if k.startswith("!") else ""}><small>{esc(k.lstrip("!"))}</small>{v}</div>' for k, v in sp['facts'])
    h.append(f'''<section class="shell opener">
  <div class="story">
    <div class="eyebrow">{esc(o['eyebrow'])}</div>
    <h2>{esc(o['h2'])}</h2>
    <p class="lede">{o['lede']}</p>
    {paras}
    <p class="draftnote">{esc(o['note'])}</p>
  </div>
  <aside class="factcard">
    <div class="eyebrow">Listing record / supplied facts</div>
    <p class="price-big">{sp['price']}</p>
    <p class="sub">{sp['sub']}</p>
    <div class="fact-list">{facts}</div>
    <a class="btn" href="book-viewing.html?home={sp['id']}">Request a private viewing ↗</a>
  </aside>
</section>''')
    if sp.get('units'):
        u = ''.join(f'<div class="unit"><div class="eyebrow">{esc(x[0])}</div><h4>{esc(x[1])}</h4><p>{x[2]}</p></div>' for x in sp['units'])
        h.append(f'<section class="shell"><div class="rule-head"><div><div class="eyebrow">{esc(sp["units_eyebrow"])}</div><h2 class="title">{esc(sp["units_title"])}</h2></div></div><div class="units">{u}</div><p class="text" style="margin-top:18px;max-width:760px">{sp["units_note"]}</p></section>')
    n, alt, cap = sp['bleed']
    h.append(f'<figure class="bleed"><img src="assets/{b}/{n}" alt="{esc(alt)}" loading="lazy"><figcaption>{esc(cap)}</figcaption></figure>')
    for i, c in enumerate(sp['chapters']):
        rev = ' rev' if i % 2 else ''
        k = len(c['imgs'])
        kc = {1: ' one', 2: ' two', 3: ''}[k]
        figs = ''.join(fig(b, im, f'f{j+1}') for j, im in enumerate(c['imgs']))
        h.append(f'''<section class="shell chap{rev}{kc}">
  <div class="chap-text"><div class="chap-num">{i+1:02d}</div><h3>{esc(c['h3'])}</h3><p>{c['p']}</p></div>
  {figs}
</section>''')
        if i == 0 and sp.get('pull'):
            q, cite = sp['pull']
            h.append(f'<section class="shell pull"><blockquote>“{esc(q)}”<cite>{esc(cite)}</cite></blockquote></section>')
    # full set
    allimgs = sp['all']
    cells = ''.join(f'<a href="assets/{b}/{n}"><img src="assets/{b}/{n}" alt="{esc(a)}" loading="lazy"></a>' for n, a in allimgs)
    h.append(f'''<section class="shell sheet">
  <div class="rule-head"><div><div class="eyebrow">The full set / {len(allimgs)} frames</div><h2 class="title">Every photograph supplied.</h2></div><span class="mono">Tap any frame to view it full screen</span></div>
  <div class="sheet-grid">{cells}</div>
</section>''')
    on = sp['ownernote']
    h.append(f'<section class="shell ownernote"><div class="eyebrow">{esc(on[0])}</div><div><h3>{esc(on[1])}</h3><p>{on[2]}</p></div></section>')
    sv = sp['service']
    h.append(f'''<section class="shell service"><div><div class="eyebrow">{esc(sv[0])}</div><h2>{esc(sv[1])}</h2><p class="text">{sv[2]}</p><p><a class="link" href="book-viewing.html?home={sp['id']}">Request a private viewing ↗</a></p></div><aside class="agent-box"><div class="eyebrow">Listing host / prototype</div><strong>Maya Lertchai</strong><p class="text">Bangkok homes · availability-first coordination</p><a class="btn" href="agent-maya.html">Meet the host ↗</a></aside></section>

<section class="shell relate"><div class="rule-head"><div><div class="eyebrow">Keep reading</div><h2 class="title">More homes in this issue.</h2></div><a class="link" href="marketplace.html">All homes ↗</a></div><div class="hcards" data-related="{sp['id']}"></div></section>

<section class="shell notice"><strong>Supplied listing data.</strong> {sp['notice']}</section>
</main>
<footer data-site-footer></footer>
<script src="i18n-th.js"></script><script src="homes-data.js"></script>
<script src="shared.js"></script>
</body>
</html>
''')
    return '\n'.join(h)

if __name__ == '__main__':
    import importlib
    out = sys.argv[1]
    for name in sys.argv[2:]:
        sp = importlib.import_module(name).SPEC
        # validate images exist
        missing = []
        imgs = [sp['hero']] + [sp['bleed'][0]] + [i[0] for c in sp['chapters'] for i in c['imgs']] + [i[0] for i in sp['all']]
        for n in imgs:
            if not os.path.exists(f"{out}/assets/{sp['dir']}/{n}"): missing.append(n)
        if missing: print('MISSING', name, missing)
        open(f"{out}/{sp['file']}", 'w').write(build(sp))
        print('wrote', sp['file'])
