D='lumpini24'
def f(n): return f'lumpini24-{n:02d}.jpg'
ALL=[(14,'Dining table beside a window with a city view'),(12,'Living and dining room with a white dome pendant lamp and a tall mirror'),(2,'Living room with sofa, television unit and balcony door'),(15,'Television unit and dining table'),(17,'Television unit and hallway'),(13,'Dining table with a tall leaning mirror'),(18,'Dining table, house-shaped shelf and pendant lamp'),(11,'House-shaped shelf and timber shelving beside the kitchen'),
 (10,'Balcony view over the rooftops and skyline'),(3,'Window with a skyline view beside a wardrobe'),
 (1,'Kitchen corner with sink and hob'),(4,'Hallway with timber doors'),(9,'Entry hall with an oval mirror and a stool'),(16,'View from a bathroom door into the living room'),
 (5,'Bedroom with a window and a skyline view'),(8,'Bedroom with a framed map and a window'),(6,'Bathroom with a basin and freestanding tub'),(7,'Bathtub and shower')]
SPEC=dict(
 id='lumpini24', dir=D, file='property-lumpini-24.html',
 title='The Lumpini 24 — a decorated home for sale',
 meta='A carefully decorated home at The Lumpini 24 near Phrom Phong, offered for sale by an owner who is retiring. Supplied photography and listing facts.',
 hero=f(14), hero_pos='center 60%', credit='Real supplied photography · supplied listing facts',
 kicker='City view / The Lumpini 24 / Sukhumvit',
 h1='Styled with care,<br>ready for its next owner.',
 dek='A home dressed with oak, black metal and a marble-topped table, high enough that the window is full of skyline.',
 opener=dict(
  eyebrow='Decorated home / The Lumpini 24',
  h2='Made to feel like someone lives here.',
  lede='Some homes are furnished to be neutral. This one was furnished to be liked: oak shelves, a black metal frame in the shape of a little house, a marble-topped dining table and a mirror tall enough to lean against the wall.',
  paras=[
   'The owner decorated it with care and has kept it in good order. Now they are retiring and want to let the property go, so the home is for sale.',
   'The Lumpini 24 is an LPN development on Sukhumvit 24, with two towers, 402 homes and a pool and gym on the upper floors. The nearest BTS station, Phrom Phong, is about 0.9 km away. From this home the windows look over a wide spread of rooftops to a skyline that includes a tall orange-red tower.',
   'The size and the exact layout are still to be confirmed. The photographs show a living and dining room, a kitchen, a bedroom with a view and a bathroom with a freestanding tub.'],
  note='Story drawn from the owner’s message, relayed by the listing team, plus the supplied photographs. Not yet reviewed by the owner.'),
 price='฿9.99M', sub='For sale · Listing ID pending',
 facts=[('Project','The Lumpini 24 · LPN'),('Layout','Pending confirmation'),('Size','Pending confirmation'),('Floor','Pending confirmation'),('Setting','Sukhumvit 24 · about 0.9 km to Phrom Phong BTS'),('Furnishing','Furnished and styled as photographed'),('Pet policy','To confirm with the building'),('Availability','To be requested')],
 bleed=(f(10),'View over rooftops and a skyline from the balcony of The Lumpini 24','The view from the balcony'),
 chapters=[
  dict(h3='A window full of skyline.',p='The balcony and the bedroom windows look across the rooftops of Khlong Toei toward the towers beyond. In the afternoon the sky does most of the decorating.',
   imgs=[(f(10),'Balcony view over rooftops and a skyline','Balcony / rooftops and skyline'),(f(3),'Window looking over the city beside a built-in wardrobe','Window / city view'),(f(2),'Living room with a sofa, television unit and balcony door','Living / balcony door')]),
  dict(h3='A living room in oak and slate.',p='A low oak and black-metal television unit sits against a pale wall with slim timber slats, and a round rug marks out the seating area. A lit ceiling edge keeps the room soft after dark.',
   imgs=[(f(12),'Living and dining room with a white pendant lamp','Living / one open room'),(f(15),'Television unit with the dining table in front','Living / television wall'),(f(17),'Television unit and a hallway beyond','Living / towards the hall')]),
  dict(h3='A table meant for dinner.',p='A white marble-topped table is laid for two under a big white dome pendant, with a house-shaped black frame and oak shelves standing guard. A tall mirror leans against the wall to double the light.',
   imgs=[(f(13),'Dining table with a tall mirror and a house-shaped shelf','Dining / mirror and shelf'),(f(14),'Dining table by the window','Dining / by the window'),(f(18),'Dining table and shelf under a white pendant lamp','Dining / pendant lamp')]),
  dict(h3='A small kitchen, tidily planned.',p='The kitchen is compact: light oak cabinets, a white worktop, an induction hob and a washing machine tucked under the counter. Open oak shelves in the dining area hold the rest.',
   imgs=[(f(1),'Kitchen corner with sink, hob and a washing machine','Kitchen / corner'),(f(11),'Open oak shelving beside the kitchen','Kitchen / open shelves'),(f(4),'Hallway with timber doors','Hall / timber doors')]),
  dict(h3='A bedroom with a view, a bath with a soak.',p='The bedroom has a pale oak headboard, a framed map and a tall window onto the skyline. The bathroom is finished in warm stone tile and has a freestanding tub.',
   imgs=[(f(5),'Bedroom with a skyline view','Bedroom / skyline'),(f(8),'Bedroom with a framed map above the bed','Bedroom / framed map'),(f(6),'Bathroom with a basin and a freestanding tub','Bathroom / freestanding tub')]),
 ],
 pull=('Furnished to be liked, not just to be neutral.','From the editors'),
 all=[(f(n),a) for n,a in ALL],
 ownernote=('In the owner’s own words · pending','What the owner enjoyed most about living here.','The story above is told by us. A few lines from the owner, such as a favourite corner or what they plan to do next, would replace it once they have reviewed the page. Nothing is attributed to them yet.'),
 service=('Viewing flow / what we confirm first','Size, floor and layout: we confirm them before you travel.','Before a viewing is accepted, the host would reconfirm availability, price, sale terms, the unit’s size, floor and bedroom count, and the building’s rules with the authorised source.'),
 notice='Photography, project name and asking price were supplied for this prototype record. Size, layout, floor and bedroom count are pending. Project facts (developer, towers, number of homes, distance to Phrom Phong BTS) come from public project information. Not represented as confirmed live inventory until source and availability are re-checked.',
)
