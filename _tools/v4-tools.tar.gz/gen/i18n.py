import json, sys, re
strings = list(json.load(open('../i18n_strings.json')).keys())

FULL = {
# --- navigation / chrome
'Collections':'คอลเลกชัน','Homes':'บ้าน','Spaces':'พื้นที่','Projects':'โครงการ','Journal':'บันทึก','Submit a home':'ลงประกาศบ้าน',
'MENU +':'เมนู +','CLOSE ×':'ปิด ×','Close':'ปิด','Meet Maya':'พบกับ Maya',
# --- home hero (headline itself stays English by design)
'Curated homes in Bangkok':'คัดสรรบ้านในกรุงเทพฯ',
'Where':'ย่าน','Anywhere in Bangkok':'ทุกย่านในกรุงเทพฯ',
'Sukhumvit & Phrom Phong':'สุขุมวิทและพร้อมพงษ์','Sathorn & Silom':'สาทรและสีลม','Thonglor & Ekkamai':'ทองหล่อและเอกมัย','Riverside & Thonburi':'ริมแม่น้ำและฝั่งธนบุรี','Sai Mai & outer Bangkok':'สายไหมและชานเมืองกรุงเทพฯ',
'Looking to':'ต้องการ','Rent or buy':'เช่าหรือซื้อ','Rent':'เช่า','Buy':'ซื้อ',
'A home that is':'บ้านแบบไหน','Any kind of life':'แบบไหนก็ได้',
'Pet-friendly':'เลี้ยงสัตว์ได้','Work from home':'ทำงานที่บ้าน','Quiet city':'เมืองที่เงียบสงบ','City views':'วิวเมือง','Family':'ครอบครัว',
'Show homes':'ดูบ้านทั้งหมด','soon':'เร็วๆ\u00a0นี้',
'Photo · The Sukhothai Residences (supplied)':'ภาพ · The Sukhothai Residences (ได้รับมา)',
'Photo · Nye by Sansiri (supplied)':'ภาพ · Nye by Sansiri (ได้รับมา)',
'Photo · The Residences at Mandarin Oriental (supplied)':'ภาพ · The Residences at Mandarin Oriental (ได้รับมา)',
# --- home sections
'Start with how you live':'เริ่มจากวิถีชีวิตของคุณ','Find a home by feeling,':'หาบ้านจากความรู้สึก','not by filter.':'ไม่ใช่จากตัวกรอง','All collections ↗':'ดูคอลเลกชันทั้งหมด ↗',
'Lifestyle':'ไลฟ์สไตล์','Setting':'ทำเล','Building':'อาคาร',
'Pet-friendly city homes':'บ้านในเมืองที่เลี้ยงสัตว์ได้','Work-from-home ready':'พร้อมทำงานที่บ้าน','The quiet city':'เมืองที่เงียบสงบ','Homes with a view':'บ้านที่มีวิว','Room for a family':'พื้นที่สำหรับครอบครัว',
'Walk to the BTS':'เดินถึง BTS','By the river':'ริมแม่น้ำ','Low-rise living':'อยู่ในอาคารเตี้ย','High-rise living':'อยู่ในตึกสูง','Collecting next':'กำลังรวบรวมเร็วๆ นี้','Central Bangkok':'ใจกลางกรุงเทพฯ',
'Know a home like this? Submit it ↗':'รู้จักบ้านแบบนี้ไหม? ลงประกาศเลย ↗',
'Issue 01':'ฉบับที่ 01','In this issue.':'ในฉบับนี้',
'A short guide to what is inside: collections to browse, a cover home to look at closely, and notes on the city around them.':'คู่มือสั้นๆ ว่าในฉบับนี้มีอะไรบ้าง: คอลเลกชันให้เลือกดู บ้านบนปกที่ควรดูใกล้ๆ และบันทึกเกี่ยวกับเมืองรอบตัว',
'Collection':'คอลเลกชัน','The Quiet City':'เมืองที่เงียบสงบ','chosen for light, privacy and a slower pace.':'คัดมาเพื่อแสงธรรมชาติ ความเป็นส่วนตัว และจังหวะชีวิตที่ช้าลง',
'Where the pet-friendly claim can be seen in the photographs.':'ที่ที่เห็นได้จากภาพถ่ายว่าเลี้ยงสัตว์ได้จริง',
'Work-from-home, properly':'ทำงานที่บ้านอย่างจริงจัง','A real second room set up as an office, not a laptop corner.':'ห้องที่สองที่จัดเป็นห้องทำงานจริง ไม่ใช่แค่มุมวางแล็ปท็อป',
'Cover home':'บ้านบนปก','Tristan Condo, Unit 11/16':'Tristan Condo ยูนิต 11/16','Fifteen frames and the story of how this two-bedroom lives.':'ภาพ 15 ใบ และเรื่องราวว่าห้อง 2 ห้องนอนนี้อยู่อาศัยอย่างไร',
'Bangkok after rain':'กรุงเทพฯ หลังฝนตก','Neighbourhood notes and the softer side of the city.':'บันทึกเรื่องย่านและมุมที่นุ่มนวลของเมือง',
'Issue 01 / Editorial selections':'ฉบับที่ 01 / คัดสรรโดยบรรณาธิการ','View the issue ↗':'ดูทั้งฉบับ ↗',
'The quiet city /':'เมืองที่เงียบสงบ /','Rooms with':'ห้องที่มี','a sense of calm.':'ความรู้สึกสงบ',
"Curator's note":'บันทึกจากบรรณาธิการ','Not every beautiful home is a collection piece.':'บ้านสวยทุกหลังไม่ได้เป็นชิ้นงานในคอลเลกชัน',
'The ones here have a quality you notice before you can name it.':'หลังที่อยู่ที่นี่มีบางอย่างที่คุณสัมผัสได้ก่อนจะบอกได้ว่าคืออะไร','Read the note ↗':'อ่านบันทึก ↗',
'Next issue':'ฉบับถัดไป','Homes with a point of view.':'บ้านที่มีมุมมองเป็นของตัวเอง','Rare light, hard-to-find layouts and rooms that stay with you.':'แสงที่หาได้ยาก ผังห้องที่หาไม่ง่าย และห้องที่ติดอยู่ในความทรงจำ',
'Bangkok after rain / neighbourhood notes':'กรุงเทพฯ หลังฝนตก / บันทึกเรื่องย่าน','The city changes when the light does.':'เมืองเปลี่ยนไปเมื่อแสงเปลี่ยน',
'Places to walk, rooms with a view and stories from the softer side of Bangkok—after the rain has washed the day away.':'ที่ให้เดินเล่น ห้องที่มีวิว และเรื่องราวจากมุมที่นุ่มนวลของกรุงเทพฯ หลังฝนชำระวันให้สะอาดไปแล้ว','Enter the journal ↗':'เข้าสู่บันทึก ↗',
'Newly curated':'คัดสรรใหม่','Homes just added.':'บ้านที่เพิ่งเพิ่มเข้ามา','Browse all homes ↗':'ดูบ้านทั้งหมด ↗',
'For owners & agents':'สำหรับเจ้าของและนายหน้า','Your home deserves more than a listing.':'บ้านของคุณควรได้มากกว่าประกาศธรรมดา',
'Selected homes receive photography, film and an editorial presentation built to help the right people discover them.':'บ้านที่ได้รับคัดเลือกจะได้รับการถ่ายภาพ วิดีโอ และการนำเสนอแบบบรรณาธิการ เพื่อให้คนที่ใช่ได้ค้นพบ',
'Explore The Home Edit ↗':'ดูรายละเอียด The Home Edit ↗',
# --- footer / modal
'Curated Bangkok homes, with a small team that checks every home before you travel to see it.':'บ้านในกรุงเทพฯ ที่คัดสรรแล้ว โดยทีมเล็กๆ ที่ตรวจสอบทุกหลังก่อนที่คุณจะเดินทางไปดู',
'Partner walkthrough ↗':'ชมภาพรวมสำหรับพาร์ทเนอร์ ↗',
'Concept prototype':'ต้นแบบแนวคิด','Coming soon.':'เร็วๆ นี้','This part of the prototype is not built yet.':'ส่วนนี้ของต้นแบบยังไม่ได้ทำ',
# --- cards / shared labels
'Availability to re-check':'ต้องตรวจสอบว่ายังว่างอยู่','Source to verify':'ต้องยืนยันแหล่งข้อมูล',
# --- marketplace
'Homes / supplied inventory':'บ้าน / รายการที่ได้รับมา','Find the one':'ค้นหาหลังที่','worth seeing.':'ควรไปดู',
'Room to live':'ขนาดห้อง','1 bedroom':'1 ห้องนอน','2+ bedrooms':'2 ห้องนอนขึ้นไป','Where it sits':'ทำเล','Near BTS':'ใกล้ BTS','Riverside':'ริมแม่น้ำ','Central':'ใจกลางเมือง',
'The building':'อาคาร','Low-rise':'อาคารเตี้ย','High-rise':'ตึกสูง','How curation works':'การคัดสรรทำงานอย่างไร',
'An editorial collection is never a paid placement. Anything sponsored will be labelled as such.':'คอลเลกชันของบรรณาธิการไม่เคยเป็นพื้นที่โฆษณาที่จ่ายเงิน สิ่งใดที่มีผู้สนับสนุนจะระบุไว้ชัดเจน',
'Ordered by editorial pick':'เรียงตามที่บรรณาธิการเลือก','Nothing matches all of that yet.':'ยังไม่มีบ้านที่ตรงกับทุกเงื่อนไข',
'We add homes every week. Loosen a filter, or tell us about a home like this.':'เราเพิ่มบ้านใหม่ทุกสัปดาห์ ลองผ่อนเงื่อนไขลง หรือแจ้งเราเรื่องบ้านแบบนี้',
'Clear filters':'ล้างตัวกรอง','Submit a home ↗':'ลงประกาศบ้าน ↗','Prototype inventory notice':'ประกาศเกี่ยวกับรายการต้นแบบ',
'Where the homes are':'บ้านอยู่ที่ไหนบ้าง','Exact addresses stay private until a viewing is confirmed.':'ที่อยู่แน่นอนจะเปิดเผยหลังยืนยันนัดชมแล้วเท่านั้น',
# --- listing-page chrome (shared by all property pages)
'Real supplied photography · supplied listing facts':'ภาพถ่ายจริงที่ได้รับมา · ข้อมูลรายการที่ได้รับ','Listing record / supplied facts':'บันทึกรายการ / ข้อมูลที่ได้รับ','Request a private viewing ↗':'ขอนัดชมบ้านแบบส่วนตัว ↗',
'Unit':'ยูนิต','Layout':'แบบห้อง','Size':'ขนาด','Floor':'ชั้น','Floors':'ชั้น','Furnishing':'เฟอร์นิเจอร์','Pet policy':'สัตว์เลี้ยง','Availability':'ความพร้อม','Bedrooms':'ห้องนอน',
'Furnished as photographed':'ตามที่เห็นในภาพ','To be requested':'รอสอบถาม','To confirm with the building':'ต้องยืนยันกับอาคาร','To confirm':'รอยืนยัน',
'For sale · Listing ID pending':'ขาย · รหัสรายการ: รอระบุ','For sale only · Listing ID pending':'ขายอย่างเดียว · รหัสรายการ: รอระบุ',
'Whole unit for sale, or rent by floor · Unit ID U1621788':'ขายทั้งยูนิต หรือเช่าแยกรายชั้น · รหัสยูนิต U1621788',
'Keep reading':'อ่านต่อ','More homes in this issue.':'บ้านอื่นๆ ในฉบับนี้','All homes ↗':'ดูบ้านทั้งหมด ↗',
'Listing host / prototype':'โฮสต์ประจำรายการ / ต้นแบบ','Bangkok homes · availability-first coordination':'บ้านในกรุงเทพฯ · ประสานงานโดยเช็กความพร้อมก่อน','Meet the host ↗':'พบโฮสต์ ↗',
'Every photograph supplied.':'ภาพถ่ายทุกใบที่ได้รับมา','Tap any frame to view it full screen':'แตะรูปใดก็ได้เพื่อดูเต็มจอ',
'In the owner’s own words · pending':'ด้วยถ้อยคำของเจ้าของ · รอข้อมูล','From the editors':'จากบรรณาธิการ','Supplied listing data.':'ข้อมูลรายการที่ได้รับ',
'Viewing flow / what we confirm first':'ขั้นตอนนัดชม / สิ่งที่เรายืนยันก่อน',
# --- Mandarin Oriental page
'Riverside / The Residences at Mandarin Oriental':'ริมแม่น้ำ / The Residences at Mandarin Oriental',
'A river home,':'บ้านริมแม่น้ำ','kept for the big nights.':'ไว้สำหรับคืนสำคัญ',
'An eleventh-floor residence on the Chao Phraya, attached to ICONSIAM, used by its owner only once or twice a year for the New Year fireworks.':'ห้องชั้น 11 ริมแม่น้ำเจ้าพระยา เชื่อมต่อกับ ICONSIAM เจ้าของใช้เพียงปีละครั้งสองครั้งเพื่อชมพลุปีใหม่',
'Riverside home / Unit 289/21':'บ้านริมแม่น้ำ / ยูนิต 289/21',
'Quiet all year, and then the whole river lights up.':'เงียบสงบทั้งปี แล้วทั้งแม่น้ำก็สว่างไสวในคืนเดียว',
'This home is lived in only once or twice a year. Its owner comes to Bangkok around the holidays and the New Year, for one reason above all: the fireworks over the river.':'บ้านหลังนี้มีคนอยู่เพียงปีละครั้งหรือสองครั้ง เจ้าของมากรุงเทพฯ ช่วงเทศกาลและปีใหม่ ด้วยเหตุผลหลักข้อเดียว คือพลุเหนือแม่น้ำ',
'The owner now wishes to sell. For a buyer who wants a place on the river for the nights that matter, or a Bangkok base that stays ready between visits, this is the case for it.':'ตอนนี้เจ้าของต้องการขาย สำหรับผู้ซื้อที่อยากมีที่อยู่ริมแม่น้ำไว้ใช้ในคืนที่สำคัญ หรือฐานในกรุงเทพฯ ที่พร้อมอยู่เสมอระหว่างการมาเยือน นี่คือเหตุผลของบ้านหลังนี้',
'2 bed · 2 bath':'2 ห้องนอน · 2 ห้องน้ำ','151 sqm':'151 ตร.ม.','Riverside, beside ICONSIAM':'ริมแม่น้ำ ติด ICONSIAM',
'The balcony, looking down the river':'ระเบียง มองลงไปตามแม่น้ำ',
'The river is the main room.':'แม่น้ำคือห้องหลักของบ้าน',
'Living / balcony and river':'ห้องนั่งเล่น / ระเบียงและแม่น้ำ','Living / the sofa and the river':'ห้องนั่งเล่น / โซฟาและแม่น้ำ','Balcony / the skyline':'ระเบียง / เส้นขอบฟ้า',
'From the editors ':'จากบรรณาธิการ',
'A living room with a sense of occasion.':'ห้องนั่งเล่นที่มีบรรยากาศของโอกาสพิเศษ',
'Living / chandeliers and rug':'ห้องนั่งเล่น / โคมระย้าและพรม','Living / lit display wall':'ห้องนั่งเล่น / ผนังโชว์ประดับไฟ','Dining / table for six':'ห้องอาหาร / โต๊ะหกที่นั่ง',
'A kitchen kept discreet.':'ครัวที่ซ่อนตัวอย่างเรียบร้อย','Kitchen / through the glass':'ครัว / ผ่านกระจก','Kitchen / full length':'ครัว / ตลอดความยาว',
'Bedrooms set back from the water.':'ห้องนอนที่ถอยลึกจากแม่น้ำ','Bedroom / river view':'ห้องนอน / วิวแม่น้ำ','Bedroom / stone headboard':'ห้องนอน / หัวเตียงหิน','Bedroom / desk corner':'ห้องนอน / มุมโต๊ะทำงาน',
'Stone, steam and a long soak.':'หิน ไอน้ำ และการแช่น้ำนานๆ','Bathroom / double vanity':'ห้องน้ำ / อ่างล้างหน้าคู่','Bathroom / the tub':'ห้องน้ำ / อ่างแช่ตัว','Bathroom / basin and shower':'ห้องน้ำ / อ่างล้างหน้าและห้องอาบน้ำ',
'What the owner looks forward to each New Year.':'สิ่งที่เจ้าของรอคอยในทุกคืนปีใหม่',
'For a river home, we confirm the details first.':'สำหรับบ้านริมแม่น้ำ เรายืนยันรายละเอียดก่อน',
}

PRE = [  # (unique English prefix, Thai)  -- prefix avoids retyping curly quotes
('A considered collection of Bangkok homes','รวบรวมบ้านในกรุงเทพฯ ที่เราคัดจากความรู้สึกเมื่อได้อยู่จริง ไม่ใช่แค่ภาพที่ดูดีบนกระดาษ'),
('Concept prototype, 2026.','ต้นแบบแนวคิด ปี 2026 ราคา ความพร้อม และสิทธิ์ในข้อมูลต้นทาง เป็นเพียงตัวอย่างจนกว่าจะตรวจสอบ บางหน้าใช้ภาพถ่ายจริงที่ได้รับมา และระบุไว้ตรงที่ปรากฏ'),
('Homes selected for clarity','บ้านที่คัดเลือกด้วยความชัดเจน ความมีเอกลักษณ์ และสถานะปัจจุบันที่ตรงไปตรงมา ไม่ใช่ปริมาณ ทุกการ์ดแสดงสิ่งที่ได้รับมา และสิ่งที่ยังต้องตรวจซ้ำ'),
('Every home here has its own supplied photography','บ้านทุกหลังที่นี่ใช้ภาพถ่ายที่ได้รับมาของหลังนั้นเอง และแสดงเฉพาะเงื่อนไขที่ได้รับ ความพร้อม เงื่อนไขทางการค้า และสิทธิ์ในข้อมูลต้นทาง ยังต้องให้ผู้มีอำนาจตรวจซ้ำ'),
('The Residences at Mandarin Oriental, Bangkok stands','The Residences at Mandarin Oriental, Bangkok ตั้งอยู่บนถนนเจริญนคร ติดแม่น้ำเจ้าพระยาและเชื่อมต่อกับ ICONSIAM อาคารสูง 52 ชั้น สร้างเสร็จปี 2019 มี 146 ยูนิต โครงการระบุบริการแบบโรงแรมสำหรับผู้อยู่อาศัย เช่น พนักงานเปิดประตูและบริการรับจอดรถ แม่บ้านและซักรีด รวมถึงเชฟส่วนตัวตามคำขอ ค่าบริการและความพร้อมให้ทีมนัดชมเป็นผู้ยืนยัน'),
('Inside, the palette is pale stone','ภายในใช้โทนหินสีอ่อน บรอนซ์เข้ม และหนังนุ่ม ห้องนั่งเล่นหันหน้าสู่แม่น้ำและเปิดออกสู่ระเบียงยาว ส่วนห้องนอนอยู่ลึกเข้าไปด้านใน เงียบกว่า เพราะบ้านถูกใช้น้อยมาก จึงนำเสนอตามที่เห็นในภาพทุกประการ คือมีเฟอร์นิเจอร์ ตกแต่งเรียบร้อย พร้อมให้เจ้าของคนต่อไปเดินทางมาพร้อมกระเป๋าใบเดียว'),
('Owner’s use of the home relayed','ข้อมูลการใช้งานบ้านมาจากเจ้าของผ่านทีมลิสติ้ง ข้อมูลโครงการมาจากข้อมูลสาธารณะของผู้พัฒนา เจ้าของยังไม่ได้ตรวจทาน'),
('From the eleventh floor the Chao Phraya','จากชั้น 11 แม่น้ำเจ้าพระยาเต็มหน้าต่าง มีเรือแล่นอยู่เบื้องล่าง เส้นขอบฟ้าของเมืองอยู่ไกลออกไป และริมน้ำของ ICONSIAM อยู่แทบเท้า ระเบียงยาวตลอดความยาวของห้องนั่งเล่น วิวจึงเป็นส่วนหนึ่งของห้อง ไม่ใช่แค่ภาพหลังกระจก'),
('“A home kept for the nights','“บ้านที่เก็บไว้สำหรับคืนที่ทั้งแม่น้ำสว่างไสว”'),
('Crystal chandeliers, black-framed','โคมระย้าคริสตัล ผนังบุกรอบดำ พรมลายหินอ่อน และโต๊ะอาหารยาวสำหรับหกที่นั่ง ทำให้ห้องหลักดูพร้อมต้อนรับแขก ผนังโชว์ที่มีชั้นวางประดับไฟเป็นจุดเด่นข้างโทรทัศน์และกรอบเตาผิง'),
('The kitchen is set apart','ครัวแยกจากห้องนั่งเล่นด้วยฉากกระจกกรอบบรอนซ์ ตู้ยาวโทนบรอนซ์ ท็อปหิน และหน้าต่างที่รับแสงจากแม่น้ำเข้ามา เป็นครัวใช้งานจริงที่ออกแบบให้ไม่เกะกะสายตาเมื่อมีแขกมา'),
('Both bedrooms have upholstered','ห้องนอนทั้งสองมีหัวเตียงหุ้มเบาะ ไม้เข้มและหินเป็นองค์ประกอบ และผ้าม่านสูง ห้องหนึ่งมองเห็นแม่น้ำได้จากเตียง อีกห้องเปิดออกสู่ระเบียง'),
('Bathrooms are finished in pale marble','ห้องน้ำบุหินอ่อนสีอ่อนฝังลายดำ ห้องหนึ่งมีอ่างล้างหน้าคู่ที่นำไปสู่อ่างแช่ตัวซึ่งมีหน้าต่างเป็นกรอบ อีกห้องมีอ่างหินและห้องอาบน้ำกระจก'),
('The story above is told by us. A few lines from the owner, such as where','เรื่องราวข้างต้นเล่าโดยทีมของเรา ข้อความสั้นๆ จากเจ้าของ เช่น ชมพลุจากตรงไหน หรือจะคิดถึงอะไร จะมาแทนที่เมื่อเจ้าของตรวจทานหน้านี้แล้ว ตอนนี้ยังไม่มีสิ่งใดอ้างว่าเป็นคำพูดของเจ้าของ'),
('Before a viewing is accepted, the host would reconfirm availability, price, sale terms, the unit','ก่อนรับนัดชม โฮสต์จะยืนยันกับผู้มีอำนาจอีกครั้งในเรื่องความพร้อม ราคา เงื่อนไขการขาย ขนาดและผังห้องนอนของยูนิต รวมถึงกฎการเข้าอาคาร ผู้มาเยือน และสัตว์เลี้ยงของอาคาร'),
('Photography, unit number, bedroom count, size, floor and asking price were supplied','ภาพถ่าย เลขยูนิต จำนวนห้องนอน ขนาด ชั้น และราคาขาย ได้รับมาสำหรับรายการต้นแบบนี้ จำนวนห้องน้ำต้องยืนยันกับข้อมูลยูนิตอีกครั้ง ข้อมูลโครงการ (52 ชั้น 146 ยูนิต สร้างเสร็จปี 2019 ริมแม่น้ำ เชื่อมต่อ ICONSIAM) มาจากข้อมูลสาธารณะของโครงการ ยังไม่ถือว่าเป็นรายการที่ยืนยันแล้วจนกว่าจะตรวจสอบแหล่งที่มาและความพร้อมอีกครั้ง'),
]

RULES = [
 (r'^(\d+) homes?$', r'$1 หลัง'),
 (r'^The full set \/ (\d+) frames$', r'ภาพชุดเต็ม / $1 ภาพ'),
 (r'^For sale · Unit ID (\S+)$', r'ขาย · รหัสยูนิต $1'),
 (r'^([\d.,]+) sqm$', r'$1 ตร.ม.'),
]

HOMES = {
 'tristan':dict(badge='ภาพถ่ายที่ได้รับมา / เลี้ยงสัตว์ได้',title='คอนโด 2 ห้องนอนที่เลี้ยงสัตว์ได้ Tristan Condo',meta=['2 ห้องนอน · 99.91 ตร.ม. · ชั้น 3 · เฟอร์นิเจอร์ครบ','ยูนิต 11/16 · ภาพถ่ายจริงที่ได้รับมา'],trust=['ต้องตรวจสอบว่ายังว่างอยู่','ต้องยืนยันแหล่งข้อมูล']),
 'mandarin':dict(badge='ภาพถ่ายที่ได้รับมา / ริมแม่น้ำ',title='บ้านริมแม่น้ำไว้สำหรับคืนสำคัญ The Residences at Mandarin Oriental',meta=['2 ห้องนอน · 151 ตร.ม. · ชั้น 11','ยูนิต 289/21 · จำนวนห้องน้ำรอยืนยัน'],trust=['ต้องตรวจสอบว่ายังว่างอยู่','ต้องยืนยันแหล่งข้อมูล']),
 'nye':dict(badge='ภาพถ่ายที่ได้รับมา / ชั้นสูง',title='ซื้อเพราะวิว Nye by Sansiri',meta=['ชั้นสูง · ขนาดและแบบห้องรอยืนยัน','ติด BTS วงเวียนใหญ่ · วิวตามคำบอกเล่าของเจ้าของ'],trust=['ต้องตรวจสอบว่ายังว่างอยู่','ต้องยืนยันแหล่งข้อมูล']),
 'w8-88-88':dict(badge='ภาพถ่ายที่ได้รับมา / อาคารเตี้ย',title='2 ชั้น 5 ห้องนอน W8 Thonglor 88/88',meta=['3 + 2 ห้องนอน หรือรวมเป็น 5 · 221.59 ตร.ม. · ชั้น 6–7','ยูนิต 88/88 · เช่าแยกรายชั้น · สุนัขน้ำหนักไม่เกิน 20 กก.'],trust=['ต้องตรวจสอบว่ายังว่างอยู่','ต้องยืนยันเรื่องบันได']),
 'w8-88-86':dict(badge='ภาพถ่ายที่ได้รับมา / ดูเพล็กซ์',title='ดูเพล็กซ์ที่บันไดเปิดถึงกัน W8 Thonglor 88/86',meta=['180.49 ตร.ม. · ชั้น 4–5 · จำนวนห้องนอนรอยืนยัน','ยูนิต 88/86 · ขายอย่างเดียว · สุนัขน้ำหนักไม่เกิน 20 กก.'],trust=['ต้องตรวจสอบว่ายังว่างอยู่','ต้องยืนยันจำนวนห้องนอน']),
 'burasiri':dict(badge='ภาพถ่ายที่ได้รับมา / บ้านเดี่ยว',title='บ้าน 5 ห้องนอนพร้อมสนามหญ้า Burasiri Watcharapol',meta=['5 ห้องนอน · 5 ห้องน้ำ · 288 ตร.ม. · ที่ดิน 494.80 ตร.ม.','บ้านเลขที่ 55/71 · 2 ชั้น'],trust=['ต้องตรวจสอบว่ายังว่างอยู่','ต้องยืนยันแหล่งข้อมูล']),
 'lumpini24':dict(badge='ภาพถ่ายที่ได้รับมา / วิวเมือง',title='ตกแต่งอย่างใส่ใจ The Lumpini 24',meta=['ขนาด ชั้น และแบบห้องรอยืนยัน','สุขุมวิท 24 · ห่างจาก BTS พร้อมพงษ์ประมาณ 0.9 กม.'],trust=['ต้องตรวจสอบว่ายังว่างอยู่','ต้องยืนยันข้อมูลยูนิต']),
 'sukhothai':dict(badge='ภาพถ่ายที่ได้รับมา / ต้องตรวจสอบเงื่อนไขอีกครั้ง',title='ห้องเพดานสูงสองชั้น The Sukhothai Residences',meta=['2 ห้องนอน · ขนาดและชั้นรอยืนยัน','ภาพถ่ายจริงที่ได้รับมา · ราคาที่ได้รับมา'],trust=['ต้องตรวจสอบว่ายังว่างอยู่','ต้องยืนยันแหล่งข้อมูล']),
 'hyde':dict(badge='ภาพถ่ายที่ได้รับมา / เงื่อนไขรอตรวจสอบ',price='เงื่อนไขรอตรวจสอบ',title='อยู่ในเมือง มองเห็นเมือง Hyde Sukhumvit 11',meta=['ข้อมูลยูนิตรอตรวจสอบ · สุขุมวิท 11','ภาพถ่ายจริงที่ได้รับมา'],trust=['ต้องยืนยันแหล่งข้อมูล','ข้อมูลรอตรวจสอบ']),
 'ramada':dict(badge='ภาพถ่ายที่ได้รับมา / เงื่อนไขรอตรวจสอบ',price='เงื่อนไขรอตรวจสอบ',title='ห้องเพดานสูงสองชั้น Ramada Plaza',meta=['ห้องแบบดูเพล็กซ์ · ข้อมูลยูนิตรอตรวจสอบ','ภาพถ่ายจริงที่ได้รับมา'],trust=['ต้องยืนยันแหล่งข้อมูล','ข้อมูลรอตรวจสอบ']),
}

dic = dict(FULL)
import importlib, glob, re as _re
_all = set(json.load(open('../all_strings.json')).keys())
for _f in glob.glob('../w4/*.html'):
    _all |= set(_re.findall(r'placeholder="([^"]*)"', open(_f).read()))

_keys = json.load(open('../todo_keys.json'))
for _m in 'abcdefghijk':
    _mod = importlib.import_module('th2'+_m)
    for _i, _t in _mod.T.items(): dic[_keys[_i]] = _t
    for _e, _t in getattr(_mod, 'EXTRA', {}).items(): dic[_e] = _t
    for _pre, _t in getattr(_mod, 'PRE', []):
        _m = [x for x in _all if x.startswith(_pre)]
        if len(_m) != 1: print('PRE2 unresolved', _pre, len(_m))
        else: dic[_m[0]] = _t

missing = []
for pre, th in PRE:
    m = [s for s in strings if s.startswith(pre)]
    if len(m) != 1: missing.append((pre, len(m))); continue
    dic[m[0]] = th
# report strings still untranslated on the three audited pages (informational)
def numeric(s): return bool(re.fullmatch(r'[\d.,–+/ ]+|[฿♡↗M]|HOMES/|BKK|Maya Lertchai|The Bangkok Edit', s))
left = [s for s in strings if s not in dic and not numeric(s) and not any(r[0].replace('(\\d+)','1') for r in [])]
out = 'window.HB_TH = ' + json.dumps({'dict': dic, 'homes': HOMES}, ensure_ascii=False, indent=0).rstrip('}') + ',\n"rules":@@};\n'
rules_js = '[' + ','.join('[/%s/,"%s"]' % (a, b) for a, b in RULES) + ']'
out = out.replace('@@', rules_js)
# rules must be a real JS array of regexes: build file by hand
js = 'window.HB_TH = {\n"dict":' + json.dumps(dic, ensure_ascii=False, indent=0) + ',\n"homes":' + json.dumps(HOMES, ensure_ascii=False, indent=0) + ',\n"rules":' + rules_js + '\n};\n'
open(sys.argv[1], 'w').write('/* HOMES/BKK Thai strings. Exact-match dictionary: anything not listed stays in English. */\n' + js)
print('entries', len(dic), 'missing prefixes', missing)
print('--- untranslated on audited pages:')
for s in left: print('  ', s[:110])
