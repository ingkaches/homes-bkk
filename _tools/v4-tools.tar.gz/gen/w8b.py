D='w8-88-86'
def f(n): return f'w8-88-86-{n:02d}.jpg'
ALL=[(12,'Living area with the glass-sided staircase'),(5,'Living room, staircase and dining table'),(16,'Dining table and living area'),(4,'Living and dining area with a day bed'),(10,'Living area with sofas and dining table'),(9,'Upper landing beside the open staircase'),
 (6,'Kitchen with timber cabinets and a steel fridge'),(17,'U-shaped kitchen with white tiles and an oven'),(13,'Room with a built-in timber cabinet'),(15,'Room with timber panelling and louvred doors'),(8,'Wardrobe wall with timber louvres'),
 (7,'Bedroom with a dark timber bed and curtains'),(18,'Bedroom with a glass-fronted linen cabinet'),(14,'Bedroom with wardrobes and an en-suite beyond'),(1,'Bedroom with a built-in wardrobe wall'),
 (2,'Bathroom with a bath and twin basins'),(11,'Bathroom with a glass-screened shower'),(3,'Bathroom with a black glass basin')]
SPEC=dict(
 id='w8-88-86', dir=D, file='property-w8-thonglor-88-86.html',
 title='W8 Thonglor 88/86 — a duplex with the staircase open',
 meta='A 180.49 sqm duplex across floors 4 and 5 of W8 Thonglor on Thong Lo 25, with an open staircase. Dogs up to 20 kg welcome.',
 hero=f(12), hero_pos='center 55%', credit='Real supplied photography · supplied listing facts',
 kicker='Low-rise / Thonglor / duplex',
 h1='One home,<br>two floors, one staircase.',
 dek='A 180.49 sqm duplex on the fourth and fifth floors of a low-rise on Thong Lo 25, joined by an open staircase.',
 opener=dict(
  eyebrow='Duplex / W8 Thonglor, Unit 88/86',
  h2='Where the staircase stays open.',
  lede='On the fourth and fifth floors of W8 Thonglor, this duplex works the way its plan intended: living and dining downstairs, a landing above, and a staircase that is open between them.',
  paras=[
   'It sits in the same building, and has the same owner, as the combined unit at 88/88, whose own staircase is currently closed so that the floors can be let as two homes. Here the staircase is open, so the home reads as one continuous space across two levels. The owner is also the owner of the building.',
   'The mood is warm and woody. Timber floors run throughout, with dark joinery, louvred timber blinds, glass-sided stairs and a kitchen of light timber and white tile. The living area holds a day bed, a massage chair and a long dining table, and the windows look out across the neighbouring rooftops and trees. The building accepts dogs up to 20 kg.',
   'The number of bedrooms is still to be confirmed. It is offered for sale only, not for rent. The photographs show several bedrooms and three bathrooms.'],
  note='Story drawn from the owner’s description, relayed by the listing team, plus the supplied photographs. Not yet reviewed by the owner.'),
 price='฿16M · for sale', sub='For sale only · Listing ID pending',
 facts=[('Unit','88/86 · W8 Thonglor'),('Floors','4 and 5 (duplex)'),('Size','180.49 sqm'),('Bedrooms','Pending confirmation'),('Setting','Low-rise · Thong Lo 25'),('Pet policy','Dogs up to 20 kg'),('Furnishing','Furnished as photographed'),('Availability','To be requested')],
 bleed=(f(5),'Living room with the glass-sided staircase and a dining table in the foreground','The staircase, from the dining table'),
 chapters=[
  dict(h3='A staircase you can walk up.',p='Glass panels run along the staircase, and a timber handrail follows it up to the landing. Seen from the living room, it turns two floors into one volume.',
   imgs=[(f(12),'Living room with glass-sided staircase at the right of the frame','Living / the staircase'),(f(5),'Living room and staircase seen from the dining end','Living / from the dining end'),(f(9),'Upper landing with a timber handrail and a window','Upstairs / the landing')]),
  dict(h3='Room to sit, eat and spread out.',p='A long timber dining table, sofas arranged around a low table and a day bed under the windows share one open room. The ceiling steps down in a recessed border with downlights.',
   imgs=[(f(16),'Timber dining table with a living area beyond','Dining / long table'),(f(4),'Living and dining area with a day bed and a leather armchair','Living / day bed and armchair'),(f(10),'Living area with sofas and a round dining table','Living / sofas')]),
  dict(h3='Timber, steel and white tile.',p='The kitchen is a U-shape of light timber with a white-tiled wall, a steel double-door fridge and a built-in oven. In the rooms beside it, dark timber wardrobes and louvred blinds repeat the warm palette.',
   imgs=[(f(17),'U-shaped kitchen with timber cabinets and a white-tiled wall','Kitchen / U-shaped'),(f(6),'Kitchen with a steel fridge and an open sliding door','Kitchen / fridge and pass'),(f(8),'Wardrobe wall with timber louvre blinds','Dressing / louvred blinds')]),
  dict(h3='Bedrooms with space around the bed.',p='The bedrooms are generous, with timber floors, long curtains, built-in wardrobes and, in one, a glass-fronted cabinet for linen.',
   imgs=[(f(7),'Bedroom with a dark timber bed and sheer curtains','Bedroom / sheer curtains'),(f(18),'Bedroom with a glass-fronted linen cabinet','Bedroom / linen cabinet'),(f(14),'Bedroom with a wardrobe wall and an en-suite beyond','Bedroom / wardrobes')]),
  dict(h3='Bathrooms in stone and dark wood.',p='Three bathrooms are shown: one with a bath and a pair of basins, one with a glass-screened shower, and one with a black glass basin.',
   imgs=[(f(2),'Bathroom with a bath, twin basins and a timber vanity','Bathroom / bath and twin basins'),(f(11),'Bathroom with a glass-screened shower and a toilet','Bathroom / shower'),(f(3),'Bathroom with a black glass basin and a toilet','Bathroom / black basin')]),
 ],
 pull=('A staircase that turns two floors into one home.','From the editors'),
 all=[(f(n),a) for n,a in ALL],
 ownernote=('In the owner’s own words · pending','What the owner would tell a buyer.','The story above is told by us. A few lines from the owner, who also owns the building, about this duplex and the street it sits on, would replace it once they have reviewed the page. Nothing is attributed to them yet.'),
 service=('Viewing flow / what we confirm first','Bedrooms, terms and dogs: we confirm all three.','Before a viewing is accepted, the host would reconfirm availability, price, sale terms, the bedroom count and layout, and the building’s current rules for dogs up to 20 kg with the authorised source.'),
 notice='Unit number, floors, size, open staircase, ownership and pet policy were supplied for this prototype record. Asking price (฿16M, for sale only) was supplied by the listing team; bedroom count is not yet supplied. Not represented as confirmed live inventory until source and availability are re-checked.',
)
