T = {}
EXTRA = {
'A duplex with the staircase open, W8 Thonglor':'ดูเพล็กซ์ที่บันไดเปิดถึงกัน W8 Thonglor',
'Sat':'ส.','Sun':'อา.','Mon':'จ.','Tue':'อ.','Wed':'พ.','November':'พฤศจิกายน',
'Home':'หน้าแรก','Source':'แหล่งข้อมูล','Bangkok':'กรุงเทพฯ','Supplied photography':'ภาพถ่ายที่ได้รับมา',
'Beside BTS Wongwian Yai':'ติด BTS วงเวียนใหญ่','A pet-friendly':'บ้านเลี้ยงสัตว์ได้','Bedroom':'ห้องนอน',
'Condo':'คอนโด','House':'บ้านเดี่ยว','Pending confirmation':'รอการยืนยัน',
}
