T = {}
EXTRA = {
'Portrait to come':'รูปถ่ายจะมาเร็วๆ นี้',
'Transaction':'ประเภทรายการ','Sale or rent':'ขายหรือเช่า',
'Scale with a real point of view.':'สเกลที่มีมุมมองจริง',
'Double-height volume and tall glazing make the living room feel architectural—not simply large.':'ห้องเพดานสูงสองชั้นและกระจกบานสูงทำให้ห้องนั่งเล่นดูเป็นงานสถาปัตยกรรม ไม่ใช่แค่ห้องกว้าง',
'Custom lit shelving, dark stone, a piano and an integrated dining zone give the home a distinct lived-in identity.':'ชั้นวางไฟซ่อนสั่งทำ หินสีเข้ม เปียโน และโซนรับประทานอาหารที่ต่อเนื่อง ให้บ้านหลังนี้มีเอกลักษณ์ของบ้านที่ถูกใช้งานจริง',
'The balcony and Sathorn-facing city outlook make the scale legible beyond the interiors.':'ระเบียงและวิวเมืองด้านสาทรทำให้เห็นสเกลของบ้านได้เกินกว่าภายในห้อง',
'Supplied gallery / 12 frames':'แกลเลอรีที่ได้รับมา / 12 ภาพ','From arrival to outlook.':'จากทางเข้าสู่วิว',
'Living / double-height volume':'ห้องนั่งเล่น / เพดานสูงสองชั้น','Dining / kitchen':'ห้องอาหาร / ครัว','City outlook':'วิวเมือง',
'Balcony / outdoor room':'ระเบียง / ห้องกลางแจ้ง','Dining / entertaining':'ห้องอาหาร / รับแขก','Arrival / living beyond':'ทางเข้า / ห้องนั่งเล่นด้านใน',
'Ask once. Re-check before the visit.':'ถามครั้งเดียว ตรวจสอบอีกครั้งก่อนไปชม',
'Real supplied photography':'ภาพถ่ายจริงที่ได้รับมา',
'Sukhumvit 24 · about 0.9 km to Phrom Phong BTS':'สุขุมวิท 24 · ห่าง BTS พร้อมพงษ์ประมาณ 0.9 กม.',
'Styled with care, The Lumpini 24':'ตกแต่งอย่างใส่ใจ The Lumpini 24',
'A pet-friendly two-bedroom, Tristan Condo':'คอนโด 2 ห้องนอนที่เลี้ยงสัตว์ได้ Tristan Condo',
'2 beds · 99.91 sqm · floor 3 · fully furnished':'2 ห้องนอน · 99.91 ตร.ม. · ชั้น 3 · เฟอร์นิเจอร์ครบ',
'Real supplied photography · facts pending source verification':'ภาพถ่ายจริงที่ได้รับมา · ข้อมูลรอตรวจสอบแหล่งที่มา',
'Real supplied photography · pricing and availability to re-check':'ภาพถ่ายจริงที่ได้รับมา · ราคาและความพร้อมต้องตรวจสอบอีกครั้ง',
'Name':'ชื่อ','+66 …':'+66 …',
'e.g. Nye by Sansiri, or Thonglor':'เช่น Nye by Sansiri หรือทองหล่อ',
'e.g. 9,900,000 or 65,000 / month':'เช่น 9,900,000 หรือ 65,000 / เดือน',
'What you changed, the view or light you love, what you will miss, why you are letting it go. A few lines is enough.':'สิ่งที่คุณเปลี่ยน วิวหรือแสงที่คุณรัก สิ่งที่จะคิดถึง และเหตุผลที่ตัดสินใจปล่อย เขียนสั้นๆ ไม่กี่บรรทัดก็พอ',
}
PRE = [
('A request for this home should capture','คำขอสำหรับบ้านหลังนี้ควรระบุว่าคุณสนใจซื้อหรือเช่า แล้วส่งต่อให้โฮสต์ที่ระบุชื่อ ก่อนยืนยันเวลา ผลิตภัณฑ์ควรตรวจสอบความพร้อมและเงื่อนไขเชิงพาณิชย์ที่ได้รับมากับผู้มีอำนาจอีกครั้ง'),
('Photography, project name, bedroom count and asking terms','ภาพถ่าย ชื่อโครงการ จำนวนห้องนอน และเงื่อนไขที่ตั้งไว้ ได้รับมาสำหรับรายการต้นแบบนี้ ยังไม่ถือเป็นรายการจริง จนกว่าจะยืนยันราคา ความพร้อม แหล่งข้อมูล/สิทธิ์ในการทำการตลาด และข้อมูลยูนิตที่เหลืออีกครั้ง'),
('For example: I','เช่น ฉันกำลังย้ายมาในเดือนพฤศจิกายน หรืออยากสอบถามเรื่องสัตว์เลี้ยง'),
]
