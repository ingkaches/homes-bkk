T = {}
EXTRA = {
'Agent portal':'พอร์ทัลเอเจนต์','Map':'แผนที่',
'An agent or partner with an invitation?':'เป็นเอเจนต์หรือพาร์ทเนอร์ที่ได้รับเชิญ?',
'Post and manage listings in the portal ↗':'ลงและจัดการประกาศในพอร์ทัล ↗',
'Homes / on the map':'บ้าน / บนแผนที่','Where the homes are.':'บ้านอยู่ตรงไหนบ้าง',
'All':'ทั้งหมด','Area':'พื้นที่','Any':'ไม่จำกัด',
'Location to be pinned':'ยังไม่ได้ปักหมุดตำแหน่ง',
'Circles show the approximate area, not the address. The exact address is shared once a viewing is booked.':'วงกลมแสดงบริเวณโดยประมาณ ไม่ใช่ที่อยู่จริง ที่อยู่เต็มจะแจ้งให้เมื่อนัดชมแล้ว',
'Map background could not load here. The pins and circles still show where the homes are.':'โหลดพื้นหลังแผนที่ไม่ได้ในที่นี้ แต่หมุดและวงกลมยังแสดงตำแหน่งบ้านอยู่',
'Nothing matches that yet.':'ยังไม่มีบ้านที่ตรงกับเงื่อนไขนี้',
'Loosen a filter, or show everything.':'ลองผ่อนตัวกรอง หรือแสดงทั้งหมด',
'Listing':'รายการ','This home is no longer listed.':'บ้านหลังนี้ไม่ได้ลงประกาศแล้ว',
'It may have been let or sold, or the link is out of date.':'อาจถูกเช่าหรือขายไปแล้ว หรือลิงก์นี้เก่าแล้ว',
'See all homes':'ดูบ้านทั้งหมด','Loading the home…':'กำลังโหลดข้อมูลบ้าน…',
}
PRE = []
