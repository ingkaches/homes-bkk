import re
s=open('the-home-edit.html').read()
hdr=re.search(r'<div class="shell"><header class="topbar">.*?</header></div>',s,re.S).group(0)
page='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Submit a home — HOMES/BKK</title><meta name="description" content="Tell us about a home you own or represent. Selected homes receive photography, a written story and an editorial presentation.">
<link rel="stylesheet" href="shared.css">
<style>
.owner-hero{min-height:620px;display:grid;grid-template-columns:1fr 1fr;background:#d9d4c8}
.owner-hero-copy{padding:8vw 6vw 48px 7vw;display:flex;flex-direction:column;justify-content:space-between;gap:40px}
.owner-hero-copy p{max-width:420px;color:#4d584c}
.owner-hero-photo{background:linear-gradient(0deg,rgba(20,29,21,.18),transparent) , url('assets/tristan-condo/tristan-dining-art.jpg') center/cover}
.receive{display:grid;grid-template-columns:repeat(3,1fr);border-top:1px solid var(--ink)}
.receive article{padding:26px 26px 32px;border-right:1px solid var(--line)}
.receive article:last-child{border-right:0}
.receive h3{font:500 28px/1.05 'Playfair Display',serif;margin:14px 0 10px}
.receive p{margin:0!important;font-size:15px!important;color:#46513f}
.example{display:grid;grid-template-columns:1.1fr .9fr;gap:0;background:var(--deep);color:#f4f0e6;margin-top:34px}
.example img{width:100%;height:100%;min-height:340px;object-fit:cover;display:block}
.example div{padding:38px;display:flex;flex-direction:column;justify-content:space-between;gap:24px}
.example h3{font:500 34px/1.04 'Playfair Display',serif;margin:10px 0}
.example p{color:#cdd7c9;margin:0!important}
.form-wrap{display:grid;grid-template-columns:.8fr 1.2fr;gap:6vw;padding:20px 0 110px;align-items:start}
.form-intro{position:sticky;top:84px}
.form-intro h2{font:500 clamp(36px,4vw,56px)/.98 'Playfair Display',serif;margin:12px 0 18px}
.form-intro ul{margin:22px 0 0;padding:0;list-style:none;border-top:1px solid var(--line)}
.form-intro li{padding:12px 0;border-bottom:1px solid var(--line);font-size:14px;color:#46513f}
.sform{background:#e7e3d8;padding:40px}
.sform fieldset{border:0;margin:0 0 30px;padding:0}
.sform legend{padding:0;margin:0 0 14px;font:500 11px 'DM Mono',monospace;letter-spacing:.12em;text-transform:uppercase;color:var(--fog)}
.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.f{display:flex;flex-direction:column;gap:6px;margin-bottom:12px}
.f label,.f .lab{font:500 11px 'DM Mono',monospace!important;letter-spacing:.08em;text-transform:uppercase;color:#59635a}
.f input[type=text],.f input[type=tel],.f input[type=email],.f input[type=number],.f select,.f textarea{width:100%;padding:13px 14px;background:#f7f5ee;border:1px solid rgba(28,37,29,.2);color:var(--ink);border-radius:0}
.f textarea{min-height:130px;resize:vertical}
.f input:focus,.f select:focus,.f textarea:focus{outline:2px solid var(--moss);outline-offset:-1px}
.f .hint{font-size:12.5px;color:var(--fog);line-height:1.5}
.seg{display:flex;flex-wrap:wrap;gap:8px}
.seg label{position:relative;font:500 14px 'DM Sans',sans-serif!important;letter-spacing:0;text-transform:none;color:var(--ink)}
.seg input{position:absolute;opacity:0}
.seg span{display:block;padding:11px 16px;background:#f7f5ee;border:1px solid rgba(28,37,29,.2);cursor:pointer}
.seg input:checked+span{background:var(--moss);color:#fff;border-color:var(--moss)}
.seg input:focus-visible+span{outline:2px solid var(--moss);outline-offset:2px}
.check{display:flex;gap:11px;align-items:flex-start;margin:10px 0;font-size:14px;line-height:1.5;color:#3a463b}
.check input{margin-top:4px;accent-color:var(--moss)}
.proto{margin:6px 0 22px;padding:14px 16px;background:#f3e6cb;border-left:3px solid var(--sand);font-size:13.5px;line-height:1.55;color:#4b4128}
.proto b{font:500 10.5px 'DM Mono',monospace;letter-spacing:.08em;text-transform:uppercase}
.err{color:#a3402a;font-size:13px;margin:4px 0 0;min-height:1em}
.sform .btn{width:100%;padding:18px;cursor:pointer;font-size:12px!important}
.thanks{background:var(--deep);color:#f4f0e6;padding:40px}
.thanks h2{font:500 clamp(34px,3.6vw,48px)/1 'Playfair Display',serif;margin:12px 0 14px}
.thanks p{color:#cdd7c9}
.sum{margin:22px 0;border-top:1px solid rgba(255,255,255,.22)}
.sum div{display:grid;grid-template-columns:150px 1fr;gap:14px;padding:11px 0;border-bottom:1px solid rgba(255,255,255,.16);font-size:14px}
.sum small{font:500 10.5px 'DM Mono',monospace;letter-spacing:.08em;text-transform:uppercase;color:#a9b8a5;padding-top:2px}
.thanks .acts{display:flex;gap:10px;flex-wrap:wrap}
.thanks .btn.ghost{color:#fff}
.faq{padding:0 0 100px}
.faq-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:0 6vw;border-top:1px solid var(--ink)}
.faq-grid div{padding:22px 0;border-bottom:1px solid var(--line)}
.faq-grid h3{font:500 22px/1.15 'Playfair Display',serif;margin:0 0 8px}
.faq-grid p{margin:0!important;font-size:15px!important;color:#46513f}
@media(max-width:900px){.owner-hero,.receive,.example,.form-wrap,.faq-grid{grid-template-columns:1fr}.owner-hero-copy{padding:50px 16px 36px}.owner-hero-photo{min-height:320px}.receive article{border-right:0;border-bottom:1px solid var(--line)}.form-intro{position:static}.sform,.thanks{padding:26px 20px}.row{grid-template-columns:1fr}.example div{padding:26px 22px}.sum div{grid-template-columns:1fr;gap:2px}}
</style></head><body>
@@HDR@@
<main>
<section class="owner-hero"><div class="owner-hero-copy"><div><div class="eyebrow">For owners &amp; agents</div><h1 class="display">Your home deserves more than a listing.</h1></div><div><p>Tell us about a home you own or represent. Homes with the right potential are chosen for photography, a written story and an editorial presentation, like the ones in this issue.</p><br><a class="btn" href="#submit">Submit your home ↓</a></div></div><div class="owner-hero-photo" role="img" aria-label="Dining table beneath colourful paintings at Tristan Condo"></div></section>

<section class="shell section"><div class="rule-head"><div><div class="eyebrow">What selected homes receive</div><h2 class="title">A listing with a life beyond the listing.</h2></div><span class="pill">Selected homes only</span></div>
<div class="receive"><article><div class="eyebrow">01 / Story</div><h3>A page that reads like a feature.</h3><p>We talk to you, then write the story of the home in a magazine spread with every photograph in view.</p></article><article><div class="eyebrow">02 / Presentation</div><h3>Photography that does the home justice.</h3><p>Homes with the right potential may be chosen for professional photography and a short film.</p></article><article><div class="eyebrow">03 / Placement</div><h3>Chosen for a collection, never sold into one.</h3><p>Editorial collections are never paid placement. Anything sponsored is labelled as such.</p></article></div>
<div class="example"><img src="assets/tristan-condo/tristan-living-sofa.jpg" alt="Living room at Tristan Condo with sofa, armchairs and balcony doors" loading="lazy"><div><div><div class="eyebrow" style="color:#c2cfbd">An example</div><h3>From a conversation to a cover home.</h3><p>Tristan Condo’s owner told us why they wanted a pet-friendly home in the city and how they renovated it. That became the first story in this issue.</p></div><a class="btn sand" href="property-tristan-condo.html">Read the Tristan Condo story ↗</a></div></div></section>

<section class="shell form-wrap" id="submit">
<div class="form-intro"><div class="eyebrow">Submit a home</div><h2>Tell us where it is, and what makes it yours.</h2><p class="text">Five minutes is enough. We read every submission, and reply to owners and verified agents within a few working days.</p><ul><li>Free to submit. No obligation to list.</li><li>Photos can be sent later, phone photos are fine.</li><li>The story is the part we care about most.</li><li>Nothing is published before you have reviewed it.</li></ul></div>
<div>
<form class="sform" id="sf" novalidate>
<div class="proto"><b>Prototype</b><br>This form is not connected yet. Nothing you type is sent or stored. When you submit, you will see a summary you can copy.</div>
<fieldset><legend>1 / About you</legend>
<div class="f"><span class="lab">I am</span><div class="seg" role="radiogroup" aria-label="I am"><label><input type="radio" name="role" value="Owner" checked><span>The owner</span></label><label><input type="radio" name="role" value="Agent"><span>An agent</span></label><label><input type="radio" name="role" value="Developer rep"><span>A developer or project rep</span></label></div></div>
<div class="row"><div class="f"><label for="name">Your name</label><input id="name" name="name" type="text" autocomplete="name"><div class="err" data-err="name"></div></div><div class="f"><label for="contact">Phone or Line</label><input id="contact" name="contact" type="text" autocomplete="tel"><div class="err" data-err="contact"></div></div></div>
<div class="f"><label for="email">Email (optional)</label><input id="email" name="email" type="email" autocomplete="email"></div></fieldset>

<fieldset><legend>2 / The home</legend>
<div class="f"><span class="lab">Looking to</span><div class="seg" role="radiogroup" aria-label="Looking to"><label><input type="radio" name="intent" value="Sell" checked><span>Sell</span></label><label><input type="radio" name="intent" value="Rent"><span>Rent</span></label><label><input type="radio" name="intent" value="Sell or rent"><span>Either</span></label></div></div>
<div class="row"><div class="f"><label for="type">Property type</label><select id="type" name="type"><option>Condo</option><option>House</option><option>Townhouse</option><option>Villa</option><option>Other</option></select></div><div class="f"><label for="where">Project or area</label><input id="where" name="where" type="text" placeholder="e.g. Nye by Sansiri, or Thonglor"><div class="err" data-err="where"></div></div></div>
<div class="row"><div class="f"><label for="beds">Bedrooms</label><input id="beds" name="beds" type="number" min="0" max="20" inputmode="numeric"></div><div class="f"><label for="size">Size in sqm (optional)</label><input id="size" name="size" type="number" min="0" inputmode="decimal"></div></div>
<div class="row"><div class="f"><label for="price">Price expectation (THB)</label><input id="price" name="price" type="text" placeholder="e.g. 9,900,000 or 65,000 / month"></div><div class="f"><label for="unit">Unit, floor or house number (optional)</label><input id="unit" name="unit" type="text"><div class="hint">Kept private until a viewing is confirmed.</div></div></div>
<label class="check"><input type="checkbox" name="pets" value="yes"> <span>The building or project allows pets</span></label></fieldset>

<fieldset><legend>3 / Its story</legend>
<div class="f"><label for="story">Why did you choose it, and what would you tell the next owner?</label><textarea id="story" name="story" placeholder="What you changed, the view or light you love, what you will miss, why you are letting it go. A few lines is enough."></textarea></div>
<div class="f"><label for="photos">Photos (optional)</label><input id="photos" name="photos" type="file" accept="image/*" multiple><div class="hint" id="photoHint">Nothing is uploaded in this prototype. In the live version, you can add photos here or send them later.</div></div></fieldset>

<fieldset><legend>4 / Permission</legend>
<label class="check"><input type="checkbox" id="auth" name="auth"> <span>I am the owner, or I am authorised by the owner to market this home.</span></label>
<div class="err" data-err="auth"></div>
<label class="check"><input type="checkbox" name="review" checked> <span>I understand HOMES/BKK will review my submission and share any story or photographs with me before they are published.</span></label></fieldset>
<button class="btn" type="submit">Review my submission ↗</button>
</form>
<div class="thanks" id="thanks" hidden><div class="eyebrow" style="color:#c2cfbd">Submission summary</div><h2>Ready for our first look.</h2><p>This is what we would receive. <b>Nothing has been sent or saved.</b> You can copy it to share with the team.</p><div class="sum" id="sum"></div><div class="acts"><button class="btn sand" type="button" id="copy">Copy summary</button><button class="btn ghost" type="button" id="edit">Edit details</button></div><p id="copied" style="margin-top:14px;min-height:1.2em"></p></div>
</div></section>

<section class="shell faq"><div class="rule-head"><div><div class="eyebrow">Before you submit</div><h2 class="title">Questions owners ask.</h2></div></div>
<div class="faq-grid"><div><h3>Does it cost anything?</h3><p>Submitting is free. Selected homes receive extra presentation; we will tell you exactly what that involves before anything is published.</p></div><div><h3>Who sees my details?</h3><p>Your contact details are only for our team. Exact addresses and unit numbers stay private until a viewing is confirmed.</p></div><div><h3>Do you only list the best homes?</h3><p>We would rather show fewer homes properly. Every home needs real photographs and honest facts, and anything unknown is marked pending.</p></div><div><h3>Can I see how a home is presented first?</h3><p>Yes. Start with the <a class="link" href="property-tristan-condo.html">Tristan Condo story</a>, or browse <a class="link" href="marketplace.html">all homes</a>.</p></div></div></section>
</main>
<footer data-site-footer></footer>
<script src="i18n-th.js"></script><script src="homes-data.js"></script><script src="shared.js"></script>
<script>
(function(){
  const $=s=>document.querySelector(s), form=$('#sf'), thanks=$('#thanks');
  const val=n=>{const e=form.elements[n]; return e?(e.type==='checkbox'?e.checked:e.value.trim()):'';};
  $('#photos').addEventListener('change',e=>{const n=e.target.files.length;$('#photoHint').textContent=n?n+(n===1?' photo':' photos')+' chosen. Nothing is uploaded in this prototype.':'Nothing is uploaded in this prototype. In the live version, you can add photos here or send them later.';});
  function setErr(k,m){const el=document.querySelector('[data-err="'+k+'"]');if(el)el.textContent=m||'';}
  form.addEventListener('submit',e=>{
    e.preventDefault(); let bad=null;
    [['name','Please tell us your name.'],['contact','Please add a phone number or Line ID.'],['where','Please tell us the project or area.']].forEach(([k,m])=>{const ok=!!val(k);setErr(k,ok?'':m);if(!ok&&!bad)bad=k;});
    const okA=val('auth');setErr('auth',okA?'':'We need this confirmation before we can review a home.');if(!okA&&!bad)bad='auth';
    if(bad){const el=form.elements[bad];el&&el.focus();return;}
    const rows=[['From',val('role')+' · '+val('name')],['Contact',val('contact')+(val('email')?' · '+val('email'):'')],['Looking to',val('intent')],['Home',val('type')+' · '+val('where')],['Bedrooms / size',[val('beds')?val('beds')+' bed':'',val('size')?val('size')+' sqm':''].filter(Boolean).join(' · ')||'Not given'],['Price expectation',val('price')||'Not given'],['Unit / house no.',val('unit')||'Not given'],['Pets allowed',val('pets')?'Yes':'Not stated'],['Photos',(form.elements.photos.files.length||0)+' chosen (not uploaded)'],['Story',val('story')||'Not given']];
    window.__sum=rows.map(r=>r[0]+': '+r[1]).join('\\n');
    $('#sum').innerHTML=rows.map(r=>'<div><small></small><span></span></div>').join('');
    [...$('#sum').children].forEach((d,i)=>{d.children[0].textContent=rows[i][0];d.children[1].textContent=rows[i][1];});
    form.hidden=true;thanks.hidden=false;thanks.scrollIntoView({behavior:'smooth',block:'start'});
  });
  $('#edit').addEventListener('click',()=>{thanks.hidden=true;form.hidden=false;form.scrollIntoView({behavior:'smooth',block:'start'});});
  $('#copy').addEventListener('click',async()=>{let ok=false;try{await navigator.clipboard.writeText(window.__sum);ok=true;}catch(e){}$('#copied').textContent=ok?'Copied.':'Could not copy automatically. Select the text above and copy it.';});
})();
</script></body></html>'''
page=page.replace('@@HDR@@',hdr)
open('the-home-edit.html','w').write(page)
